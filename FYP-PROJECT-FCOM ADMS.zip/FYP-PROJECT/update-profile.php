<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $admin_id = $_POST['admin_id'];
    $admin_name = $_POST['admin_name'];
    $phone_number = $_POST['phone_number'];
    $profile_pic = $_FILES['profile_pic']['name'];

    // Handle file upload if a new file is provided
    if ($profile_pic) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($profile_pic);
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target_file);

        $sql = "UPDATE managea SET admin_name='$admin_name', phone_number='$phone_number', profile_pic='$profile_pic' WHERE admin_id='$admin_id'";
    } else {
        $sql = "UPDATE managea SET admin_name='$admin_name', phone_number='$phone_number' WHERE admin_id='$admin_id'";
    }

    if ($con->query($sql) === TRUE) {
        header('Location: co-profile.php');
    } else {
        echo "Error updating record: " . $con->error;
    }

    $con->close();
}
?>
