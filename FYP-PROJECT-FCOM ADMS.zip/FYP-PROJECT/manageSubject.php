<?php
session_start();
include 'database.php'; 

$notification = "";

// Handle adding a subject
if (isset($_POST['create_subject'])) {
    $subject_name = $_POST['subject_name'];
    $subject_code = $_POST['subject_code'];
    $credit_hours = $_POST['credit_hours'];
    $contact_hours = $_POST['contact_hours'];
    $subject_section = $_POST['subject_section'];

    // Check if subject already exists
    $check_sql = "SELECT * FROM subjects WHERE subject_code = '$subject_code'";
    $check_result = mysqli_query($con, $check_sql);
    if (mysqli_num_rows($check_result) > 0) {
        $notification = "Subject already exists!";
    } else {
        // Insert new subject
        $sql = "INSERT INTO subjects (subject_name, subject_code, credit_hours, contact_hours, subject_section)
                VALUES ('$subject_name', '$subject_code', '$credit_hours', '$contact_hours', '$subject_section')";
        if (mysqli_query($con, $sql)) {
            $notification = "Subject created successfully!";
        } else {
            $notification = "Error creating subject!";
        }
    }
}

// Handle deleting a subject
if (isset($_POST['update_subject'])) {
    $subject_name = $_POST['edit_subject_name'];
    $subject_code = $_POST['edit_subject_code'];
    $credit_hours = $_POST['edit_credit_hours'];
    $contact_hours = $_POST['edit_contact_hours'];
    $subject_section = $_POST['edit_subject_section'];

    $sql = "UPDATE subjects SET 
            subject_name='$subject_name', 
            credit_hours='$credit_hours', 
            contact_hours='$contact_hours', 
            subject_section='$subject_section' 
            WHERE subject_code='$subject_code'";

    if (mysqli_query($con, $sql)) {
        $notification = "Subject updated successfully!";
    } else {
        $notification = "Error updating subject!";
    }
}

// Fetch all subjects from the database
$sql = "SELECT * FROM subjects";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subjects</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body 
        {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        nav ul 
        {
            background-color: #4c8bf5;
            padding: 15px;
            list-style-type: none;
            margin: 0;
            text-align: center;
        }

        nav ul li 
        {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a 
        {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            margin: 40px auto;
            max-width: 800px;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h2 {
            color: #354a5f;
            text-align: center;
            margin-bottom: 20px;
        }

        .notification {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 10px;
            margin-bottom: 20px;
            text-align: center;
            border-radius: 5px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
            color: #354a5f;
        }

        input[type="text"], select {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #354a5f;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #4a5f78;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #354a5f;
            color: white;
        }

        td 
        {
            background-color: #f4f7fc;
        }

        td a 
        {
            color: #354a5f;
            text-decoration: none;
        }

        td a:hover 
        {
            text-decoration: underline;
        }

        .action-btns 
        {
            display: flex;
            gap: 10px;
        }

        .action-btns a 
        {
            padding: 6px 10px;
            border-radius: 5px;
            color: white;
            text-decoration: none;
            font-size: 14px;
        }

        .edit-btn 
        {
            background-color: #28a745;
        }

        .delete-btn 
        {
            background-color: #dc3545;
        }

        .delete-btn:hover, .edit-btn:hover 
        {
            opacity: 0.9;
        }

        @media (max-width: 768px) 
        {
            form, table {
                width: 100%;
                overflow-x: auto;
            }

            table, th, td {
                font-size: 14px;
            }
        }

        .modal 
        {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content 
        {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .modal-content h2 
        {
            margin-top: 0;
        }

        .close-btn 
        {
            float: right;
            font-size: 20px;
            cursor: pointer;
        }

        .modal input[type="text"], .modal select 
        {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .modal input[type="submit"] 
        {
            background-color: #354a5f;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .modal input[type="submit"]:hover 
        {
            background-color: #4a5f78;
        }

        footer 
        {
            text-align: center;
            padding: 20px;
            background-color: #4c8bf5;
            color: white;
            margin-top: 20px;
        }

        footer p 
        {
            margin: 0;
        }
    </style>
    <script>
        function confirmDelete(subject_code) {
            if (confirm("Are you sure you want to delete this subject?")) {
                window.location.href = "manageSubject.php?delete_subject=" + subject_code;
            }
        }

        // Function to open the modal and populate it with subject details
        function openEditModal(subject) 
        {
            document.getElementById('edit_subject_name').value = subject.subject_name;
            document.getElementById('edit_subject_code').value = subject.subject_code;
            document.getElementById('edit_credit_hours').value = subject.credit_hours;
            document.getElementById('edit_contact_hours').value = subject.contact_hours;
            document.getElementById('edit_subject_section').value = subject.subject_section;

            document.getElementById('editModal').style.display = 'flex';
        }

        // Close modal
        function closeModal() {
            document.getElementById('editModal').style.display = 'none';
        }
    </script>
</head>
<body>
<header>
        <nav>
            <ul>
                <li><a href="admin-home.php">Home</a></li>
                <li><a href="manageAdmin.php">Admin</a></li>
                <li><a href="manageStudent.php">Student</a></li>
                <li><a href="manageSubject.php">Subject Management</a></li>
                <li><a href="admin-login.php">Logout</a></li>
            </ul>
        </nav>
</header>>

    <main>
        <h2>Add New Subject</h2>

        <?php if ($notification): ?>
            <div class="notification"><?php echo $notification; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="subject_name">Subject Name:</label>
            <input type="text" name="subject_name" id="subject_name" required>

            <label for="subject_code">Subject Code:</label>
            <input type="text" name="subject_code" id="subject_code" required>

            <label for="credit_hours">Credit Hours:</label>
            <select name="credit_hours" id="credit_hours" required>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>

            <label for="contact_hours">Contact Hours:</label>
            <select name="contact_hours" id="contact_hours" required>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>

            <label for="subject_section">Subject Section:</label>
            <select name="subject_section" id="subject_section" required>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
            </select>

            <input type="submit" name="create_subject" value="Add Subject">
        </form>

        <h2>List of Subjects</h2>
        <table>
            <thead>
                <tr>
                    <th>Subject Name</th>
                    <th>Subject Code</th>
                    <th>Credit Hours</th>
                    <th>Contact Hours</th>
                    <th>Section</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $row['subject_name']; ?></td>
                        <td><?php echo $row['subject_code']; ?></td>
                        <td><?php echo $row['credit_hours']; ?></td>
                        <td><?php echo $row['contact_hours']; ?></td>
                        <td><?php echo $row['subject_section']; ?></td>
                        <td class="action-btns">
                            <a href="editSubject.php?subject_code=<?php echo $row['subject_code']; ?>" class="edit-btn">Edit</a>
                            <a href="#" onclick="confirmDelete('<?php echo $row['subject_code']; ?>')" class="delete-btn">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>&copy; 2024 FCOM ADMS. All Rights Reserved.</p>
    </footer>
</body>
</html>
