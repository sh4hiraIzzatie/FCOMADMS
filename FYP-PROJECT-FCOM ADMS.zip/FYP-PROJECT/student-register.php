<?php
session_start();
include("database.php");

if (isset($_POST['register'])) {
    $student_id = $_POST['student_id'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate matrix ID format
    if (!preg_match('/^AM\d{10}$/', $student_id)) {
        echo "<script>alert('Student ID format is incorrect. It must start with AM followed by 10 digits.');</script>";
        exit();
    }

    // Database connection
    $con = new mysqli('localhost', 'root', '', 'fcomadms');

    // Check connection
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    // Check if student_id already exists
    $stmt_check = $con->prepare("SELECT * FROM studentld WHERE student_id = ?");
    $stmt_check->bind_param("s", $student_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();

    if ($result->num_rows > 0) {
        // Student ID already exists
        echo "<script>alert('Registration failed. This Student ID is already registered.');</script>";
        exit();
    }

    // Insert data into the database
    $stmt = $con->prepare("INSERT INTO studentld (student_id, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $student_id, $email, $password);

    if ($stmt->execute()) {
        // Registration successful
        echo "<script>
                alert('Successfully registered! Please login');
                window.location.href = 'student-login.php';
              </script>";
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $con->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <style>
        body {
    font-family: 'Arial', sans-serif;
    background-image: url('img/uptm.jpg'); /* Set the background image */
    background-size: cover; /* Cover the entire viewport */
    background-position: center; /* Center the background image */
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    position: relative; /* Positioning context for the pseudo-element */
    overflow: hidden; /* Prevents overflow */
}

body::before {
    content: '';
    position: absolute; /* Positioned over the background */
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5); /* Dark overlay with 50% opacity */
    z-index: 1; /* Ensure overlay is on top of the background */
}

.register-container {
    position: relative; /* Positioning context for the container */
    background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
    padding: 40px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    border-radius: 12px;
    width: 400px; /* Container width */
    text-align: center;
    z-index: 2; /* Ensure the registration container is above the overlay */
}

        .register-container:hover {
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.3); /* Increase shadow on hover */
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
            font-weight: 600;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: center; /* Center inputs */
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            width: 80%; /* Adjust width as needed */
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #007bff;
            outline: none;
        }

        button[type="submit"] {
            padding: 12px;
            font-size: 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 60%; /* Set a fixed width for the button */
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .login-link {
            margin-top: 20px;
        }

        .login-link a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        .footer {
            margin-top: 20px;
            font-size: 12px;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Registration</h2>
        <form action="student-register.php" method="POST">
            <label for="student_id">Student ID (e.g., AMXXXXXXXXXX):</label>
            <input type="text" id="student_id" name="student_id" pattern="^AM\d{10}$" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password (max 12 characters):</label>
            <input type="password" id="password" name="password" maxlength="12" required>

            <button type="submit" name="register">Register</button>
        </form>

        <div class="login-link">
            <p>Already registered? <a href="student-login.php">Login here</a></p>
        </div>

        <div class="footer">
            &copy; 2024 FCOM Add Drop Management System.
        </div>
    </div>
</body>
</html>
