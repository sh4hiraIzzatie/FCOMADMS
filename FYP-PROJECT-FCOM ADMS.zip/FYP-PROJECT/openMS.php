<?php
session_start();
include("database.php");  // Include your database connection

// Get student ID from the URL
$studentId = $_GET['student_id'] ?? null;

if (!$studentId) {
    echo "Student ID not provided.";
    exit;
}

// Fetch all student details from the `studentld` table
$studentQuery = "SELECT student_name, ic_no, student_id, email, programme_name, programme_code, semester, session, active FROM studentld WHERE student_id = ?";
$studentStmt = $con->prepare($studentQuery);
$studentStmt->bind_param('s', $studentId);
$studentStmt->execute();
$studentResult = $studentStmt->get_result();
$student = $studentResult->fetch_assoc();
$studentStmt->close();

// Fetch approved applications for the student
$requestQuery = "SELECT subject_name, subject_code, credit_hours, subject_section, status 
                 FROM add_drop_application 
                 WHERE student_id = '$studentId' AND status = 'approved'";
$requestResult = $con->query($requestQuery);

// Redirect to admin-approvestud.php on approval
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['action'] === 'Approve') {
        header("Location: admin-approvestud.php?student_id=$studentId");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FCOM - Student Add/Drop Approval</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Roboto', sans-serif; }
        body { background-color: #f1f5f9; display: flex; flex-direction: column; align-items: center; color: #333; padding: 20px; }
        .header { width: 100%; background-color: #0d47a1; color: white; padding: 15px 20px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); border-radius: 8px; }
        .header h1 { font-size: 26px; font-weight: bold; margin: 0; }
        .header-nav a { color: white; text-decoration: none; font-size: 16px; font-weight: bold; margin-left: 20px; }
        .header-nav a:hover { text-decoration: underline; }
        .message { background-color: #dff0d8; color: #3c763d; padding: 15px; margin: 20px 0; border-radius: 5px; font-weight: bold; font-size: 16px; text-align: center; }
        .student-details, .table-container { background-color: #F1F1F1; padding: 20px; margin: 20px; border-radius: 8px; width: 80%; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; background-color: white; border-radius: 8px; overflow: hidden; margin-top: 20px; }
        table th, table td { padding: 15px; text-align: center; font-size: 16px; }
        th { background-color: #0d47a1; color: white; font-weight: bold; text-transform: uppercase; }
        tr:hover { background-color: #f1f5f9; }
        .approve-button { border: none; border-radius: 12px; padding: 0.5rem 1.5rem; font-weight: bold; cursor: pointer; background-color: #28A745; color: white; transition: background-color 0.2s; }
        .approve-button:hover { background-color: #218838; }
    </style>
</head>
<body>
<div class="header">
    <h1>FCOM ADD DROP MANAGEMENT SYSTEM</h1>
    <div class="header-nav">
        <a href="managestud.php">Back</a>
    </div>
</div>

<!-- Approval Message -->
<div class="message">This student application has been approved by Coordinator</div>

<div class="student-details">
        <p><strong>STUDENT DETAILS</strong></p>
        <?php if (isset($student)): ?>
            <p><strong>Full Name:</strong> <?php echo htmlspecialchars($student['student_name']); ?></p>
            <p><strong>IC No:</strong> <?php echo htmlspecialchars($student['ic_no']); ?></p>
            <p><strong>Student ID:</strong> <?php echo htmlspecialchars($student['student_id']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></p>
            <p><strong>Semester:</strong> <?php echo htmlspecialchars($student['semester']); ?></p>
            <p><strong>Session:</strong> <?php echo htmlspecialchars($student['session']); ?></p>
            <p><strong>Active:</strong> <?php echo $student['active'] === 'Y' ? 'Yes' : 'No'; ?></p>
        <?php else: ?>
            <p>No student details found.</p>
        <?php endif; ?>
    </div>
</div>

<div class="table-container">
    <h2>REQUEST DETAILS</h2>
    <table>
        <thead>
            <tr>
                <th>Subject Name</th>
                <th>Subject Code</th>
                <th>Credit Hours</th>
                <th>Section</th>
                <th>Coordinator approved</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($requestResult->num_rows > 0): ?>
                <?php while ($row = $requestResult->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['subject_code']); ?></td>
                        <td><?php echo htmlspecialchars($row['credit_hours']); ?></td>
                        <td><?php echo htmlspecialchars($row['subject_section']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">No approved applications found for this student.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <!-- BKR Approval Action -->
    <form method="POST">
        <button type="submit" name="action" value="Approve" class="approve-button">Approve Application</button>
    </form>
</div>
</body>
</html>
