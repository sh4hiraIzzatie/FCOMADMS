<?php
session_start();
include 'database.php';

// Initialize counts
$pending_count = $approved_count = $rejected_count = 0;

// Fetch application counts from the database
$sql_pending = "SELECT COUNT(*) as count FROM add_drop_application WHERE status = 'pending'";
$sql_approved = "SELECT COUNT(*) as count FROM add_drop_application WHERE status = 'approved'";

$pending_result = $con->query($sql_pending);
$approved_result = $con->query($sql_approved);

if ($pending_result->num_rows > 0) {
    $pending_count = $pending_result->fetch_assoc()['count'];
}
if ($approved_result->num_rows > 0) {
    $approved_count = $approved_result->fetch_assoc()['count'];
}

$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FCOM ADMS - BKR Home Page</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color: #f1f5f9;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #333;
            padding: 20px;
        }

        /* Header Styling */
        .header {
            width: 100%;
            background-color: #0b0e33;
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 15px;
        }

        .logo1{
            width: 120px;
            height: 60px;
            margin: 0 5px;
        }

        .logo2{
            width: 115px;
            height: 80px;
            margin: 0 5px;
        }

        .header h1 {
            font-size: 26px;
            font-weight: bold;
            margin: 0;
        }

        .header-nav a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            margin-left: 20px;
        }

        .header-nav a:hover {
            text-decoration: underline;
        }



        /* Status container styling */
        .container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin: 40px auto;
            max-width: 1000px;
            gap: 20px;
        }

        .status-box {
            width: 220px;
            height: 150px;
            background-color: white;
            color: #283593;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
            padding: 20px;
            font-weight: bold;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .status-box:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .status-box p:first-child {
            font-size: 18px;
            font-weight: 600;
            color: #283593;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .status-box p:last-child {
            font-size: 36px;
            color: #444;
        }

        /* Button container styling */
        .button-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 40px;
        }

        .button {
            width: 220px;
            height: 60px;
            background: #1a73e8;
            color: white;
            border-radius: 8px;
            text-align: center;
            line-height: 60px;
            font-weight: bold;
            text-decoration: none;
            font-size: 18px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: background 0.3s, transform 0.2s;
        }

        .button:hover {
            background: #0c47a1;
            transform: translateY(-5px);
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .container, .button-container {
                flex-direction: column;
                align-items: center;
            }

            .status-box, .button {
                width: 90%;
            }
        }

        /* FAQ Container */
        .faq-container {
            max-width: 900px;
            margin: 50px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
        }

        /* FAQ Header */
        .faq-container h1 {
            text-align: center;
            color: #333333;
            font-size: 32px;
            margin-bottom: 30px;
            position: relative;
        }

        .faq-container h1::after {
            content: "";
            width: 80px;
            height: 4px;
            background: linear-gradient(to right, #007bff, #00c6ff);
            display: block;
            margin: 10px auto 0;
            border-radius: 2px;
        }

        /* Individual FAQ Items */
        .faq {
            margin-bottom: 25px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .faq:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .faq h2 {
            font-size: 20px;
            margin-bottom: 10px;
            color: #007bff;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .faq h2:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .faq p {
            margin: 0;
            font-size: 16px;
            color: #555555;
            line-height: 1.6;
        }

        /* Alternating background for FAQs */
        .faq:nth-child(odd) {
            background: #f1f1f1;
        }

        .faq:nth-child(even) {
            background: #ffffff;
        }

        /* Hover effects for FAQ content */
        .faq:hover h2 {
            color: #004085;
        }
    </style>
</head>
<body>

<div class="header">
    <div class="logo-container">
        <img class="logo1" src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img class="logo2" src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
    <h1>FCOM ADD DROP MANAGEMENT SYSTEM</h1>
    <div class="header-nav">
        <a href="bkrhome.php">Home</a>
        <a href="admin-login.php">Log Out</a>
    </div>
</div>

<div class="container">
    <div class="status-box">
        <p>Pending</p>
        <p><?php echo $pending_count; ?></p>
    </div>
    <div class="status-box">
        <p>Approved</p>
        <p><?php echo $approved_count; ?></p>
    </div>
</div>

<div class="button-container">
    <a href="managesub.php" class="button">Subject List</a>
    <a href="adminmngmt.php" class="button">Manage Admin</a>
    <a href="managestud.php" class="button">Add/Drop Application</a>
    <form action="generate_report.php" method="POST" style="display: inline;">
        <button type="submit" name="action" value="download" class="button">Download CSV</button>
    </form>
</div>

<div class="faq-container">
    <h1>Frequently Asked Questions</h1>

    <div class="faq">
        <h2>1. How to check the list of add drop subject application?</h2>
        <p>
            Step 1 - Click the "Add Drop Request Button".<br>
            Step 2 - The application list will be display on the next page after user click on that button.<br>
            Step 3 - To see the pending, approved or rejected application, user can just select the view option on the search bar and click search.<br>
            Step 4 - User also can search the student add drop application based on their student id by just key in the student id and click "Search" then system will display the selected student add drop application.</br>
        </p>
    </div>

    <div class="faq">
        <h2>2. How do I approve the student add drop application?</h2>
        <p>
            To approved the application, select the student under the pending application status, and click "Open" to view their application details.<br>
            The system will show you the details of add drop subject and student details. Under all of the details, there will be "Approve" button.<br>
            To approve, just click that button then the system will redirect admin into the new page.<br>
            But the admin are required to update the student subject slip before click "Submit Changes" button.
        </p>
    </div>

    <div class="faq">
        <h2>3. How to generate the report?</h2>
        <p>
            To generate the report, user can click the "Download CSV" menu and system will automatically download it.
        </p>
    </div>
</div>

</body>
</html>
