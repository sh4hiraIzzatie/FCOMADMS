<?php
session_start();
include("database.php");

$error_message = '';

if (isset($_POST['login'])) {
    $student_id = $_POST['student_id'];
    $password = $_POST['password'];

    // Database connection
    $con = new mysqli('localhost', 'root', '', 'fcomadms');

    // Check connection
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    // Check login credentials
    $stmt = $con->prepare("SELECT * FROM studentld WHERE student_id = ? AND password = ?");
    $stmt->bind_param("ss", $student_id, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Login successful, redirect to studenthome.php with success message
        $_SESSION['student_id'] = $student_id; // Store student ID in session
        header("Location: studenthome.php?login=success");
        exit();
    } else {
        // Set error message
        $error_message = "Invalid Student ID or Password.";
    }

    $stmt->close();
    $con->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>

    <style>
       body 
       {
           font-family: 'Arial', sans-serif;
           background-image: url('img/uptm.jpg'); /* Set the background image */
           background-size: cover; /* Cover the entire viewport */
           background-position: center; /* Center the background image */
           display: flex;
           justify-content: center;
           align-items: center;
           height: 100vh;
           margin: 0;
           position: relative; /* Positioning context for the pseudo-element */
           overflow: hidden; /* Prevents overflow */
       }

       body::before 
       {
           content: '';
           position: absolute; /* Positioned over the background */
           top: 0;
           left: 0;
           right: 0;
           bottom: 0;
           background-color: rgba(0, 0, 0, 0.5); /* Dark overlay with 50% opacity */
           z-index: 1; /* Ensure overlay is on top of the background */
       }

       .login-container 
       {
           position: relative; /* Positioning context for the container */
           background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
           padding: 40px;
           box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
           border-radius: 12px;
           width: 400px; /* Container width */
           text-align: center;
           z-index: 2; /* Ensure the registration container is above the overlay */
       }

       .login-container:hover {
           box-shadow: 0 12px 24px rgba(0, 0, 0, 0.3); /* Increase shadow on hover */
       }

       h2 {
           color: #333;
           margin-bottom: 20px;
           font-weight: 600;
       }

       .logo-container {
           display: flex;
           justify-content: center;
           gap: 10px;
           margin-bottom: 20px;
       }

       .logo-container img {
           width: 80px; /* Adjust width as needed */
           height: auto; /* Maintain aspect ratio */
       }

       form {
           display: flex;
           flex-direction: column;
           gap: 15px;
           align-items: center; /* Center inputs */
       }

       input[type="text"],
       input[type="password"] {
           padding: 12px;
           font-size: 16px;
           border: 1px solid #ccc;
           border-radius: 8px;
           width: 80%; /* Adjust width as needed */
           transition: border-color 0.3s;
       }

       input[type="text"]:focus,
       input[type="password"]:focus {
           border-color: #007bff;
           outline: none;
       }

       button[type="submit"] {
           padding: 12px;
          font-size: 16px;
           background-color: #007bff;
           color: white;
           border: none;
           border-radius: 8px;
           cursor: pointer;
           transition: background-color 0.3s;
           width: 60%; /* Set a fixed width for the button */
       }

       button[type="submit"]:hover {
           background-color: #0056b3;
       }

       .register-link {
           margin-top: 20px;
           font-size: 15px;
       }

       .register-link a {
           color: #007bff;
           text-decoration: none;
           font-weight: bold;
       }

       .register-link a:hover {
           text-decoration: underline;
       }

       .footer {
           margin-top: 20px;
           font-size: 12px;
           color: #777;
       }

       /* Modal styles */
       .modal {
           display: none;
           position: fixed;
           z-index: 1;
           left: 0;
           top: 0;
           width: 100%;
           height: 100%;
           background-color: rgba(0, 0, 0, 0.5);
           justify-content: center;
           align-items: center;
       }

       .modal-content {
           background-color: #fff;
           padding: 20px;
           border-radius: 8px;
           box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
           text-align: center;
       }

       .modal-content p {
           font-size: 18px;
           color: red;
       }

       .close-btn {
           background-color: #007bff;
           color: white;
           border: none;
           padding: 10px 15px;
           font-size: 16px;
           cursor: pointer;
           border-radius: 5px;
           transition: background-color 0.3s;
       }

       .close-btn:hover {
           background-color: #0056b3;
       }
    </style>
</head>
<body>
<div class="login-container">
    <div class="logo-container">
        <img src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
    <h1>FCOM ADMS LOGIN</h1>
    <form action="student-login.php" method="POST">
        <label for="student_id">Student Id:</label>
        <input type="text" id="student_id" name="student_id" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit" name="login">Login</button>
    </form>

    <div class="register-link">
        <p>New user? <a href="student-register.php">Please register here</a></p>
    </div>

    <div class="footer">
        &copy; 2024 FCOM Add Drop Management System.
    </div>
</div>

    <!-- Modal (Pop-up box) -->
    <div id="errorModal" class="modal">
        <div class="modal-content">
            <p><?php echo $error_message; ?></p>
            <button class="close-btn" onclick="closeModal()">Close</button>
        </div>
    </div>

    <script>
        // Function to close modal
        function closeModal() {
            document.getElementById('errorModal').style.display = 'none';
        }

        // Show modal if there is an error message
        <?php if (!empty($error_message)): ?>
            document.getElementById('errorModal').style.display = 'flex';
        <?php endif; ?>
    </script>
</body>
</html>


