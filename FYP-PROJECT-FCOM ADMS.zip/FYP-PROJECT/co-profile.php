<?php
session_start();
include 'database.php';

// Ensure a valid admin ID is set, potentially from a session or a known source
$admin_id = $_SESSION['admin_id'] ?? 'your_admin_id'; // Replace this with dynamic logic as needed

    // Fetch all admin details from the studentld table
    $adminQuery = "SELECT admin_id, admin_name, admin_email, phone_number FROM managea WHERE admin_id = ?";
    $adminStmt = $con->prepare($adminQuery);
    $adminStmt->bind_param('s', $adminId);
    $adminStmt->execute();
    $adminResult = $adminStmt->get_result();
    $admin = $adminResult->fetch_assoc();
    $adminStmt->close();

// Validate the connection and query execution
if ($con) {
    $sql = "SELECT * FROM managea WHERE admin_id = '$admin_id'";
    $result = $con->query($sql);

    if ($result && $result->num_rows > 0) {
        $admin = $result->fetch_assoc();
    } else {
        $admin = [
            'admin_name' => 'N/A',
            'admin_email' => 'N/A',
            'phone_number' => 'N/A',
            'profile_pic' => ''
        ];
        echo "<p style='color: red; text-align: center;'>No admin data found or invalid admin ID.</p>";
    }
} else {
    echo "<p style='color: red; text-align: center;'>Database connection error: " . $con->connect_error . "</p>";
}

// Close the database connection after use
$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible=IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color: #e8eef3;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #333;
            padding: 20px;
        }

        /* Header Styling */
        .header {
            width: 100%;
            background-color: #0d47a1;
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .header h1 {
            font-size: 26px;
            font-weight: bold;
            margin: 0;
        }

        .header-nav a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            margin-left: 20px;
        }

        .header-nav a:hover {
            text-decoration: underline;
        }

        .profile-container {
            background-color: #ffffff;
            margin: 20px;
            padding: 25px;
            border-radius: 15px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border: 2px solid #ccc;
        }

        .profile-info {
            margin-bottom: 20px;
            text-align: center;
        }

        .profile-info h2 {
            margin-bottom: 20px;
            color: #0d47a1;
        }

        .profile-info div {
            margin-bottom: 15px;
            font-size: 18px;
        }

        .profile-picture {
            border: 2px solid #0d47a1;
            border-radius: 50%;
            height: 150px;
            width: 150px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: auto;
            background-color: #f1f5f9;
            overflow: hidden;
        }

        .profile-picture img {
            height: 100%;
            width: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .edit-button {
            display: block;
            background-color: #5A67D8;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px auto;
            text-align: center;
            font-size: 16px;
        }

        .edit-button:hover {
            background-color: #434190;
        }

        /* Modal Styling */
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #ffffff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            max-width: 400px;
            width: 100%;
        }

        .modal-header {
            font-size: 20px;
            margin-bottom: 15px;
            color: #0d47a1;
        }

        .modal input[type="text"], .modal input[type="email"], .modal input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .modal button {
            background-color: #5A67D8;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .modal button:hover {
            background-color: #434190;
        }

        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 500;
        }
    </style>
    <script>
        function openModal() {
            document.querySelector('.modal').style.display = 'block';
            document.querySelector('.modal-overlay').style.display = 'block';
        }

        function closeModal() {
            document.querySelector('.modal').style.display = 'none';
            document.querySelector('.modal-overlay').style.display = 'none';
        }
    </script>
</head>
<body>

<div class="header">
    <h1>FCOM ADD DROP MANAGEMENT SYSTEM</h1>
    <div class="header-nav">
        <a href="co-home.php">HOME</a>
        <a href="co-profile.php">PROFILE</a>
        <a href="co-login.php">LOG OUT</a>
    </div>
</div>

<div class="sdetails-container">
    <div class="student-details">
        <p><strong>STUDENT DETAILS</strong></p>
        <?php if (isset($student)): ?>
            <p><strong>ID :</strong> <?php echo htmlspecialchars($admin['admin_id']); ?></p>
            <p><strong>NAME :</strong> <?php echo htmlspecialchars($admin['admin_name']); ?></p>
            <p><strong>EMAIL :</strong> <?php echo htmlspecialchars($admin['admin_email']); ?></p>
            <p><strong>PHONE NUMBER :</strong> <?php echo htmlspecialchars($admin['phone_number']); ?></p>
        <?php else: ?>
            <p>No admin details found.</p>
        <?php endif; ?>
    </div>
</div>

<div class="profile-container">
    <div class="profile-info">
        <h2>ADMIN PROFILE</h2>
        <div><strong>NAME :</strong> <?php echo htmlspecialchars($admin['admin_name']); ?></div>
        <div><strong>EMAIL :</strong> <?php echo htmlspecialchars($admin['admin_email']); ?></div>
        <div><strong>PHONE NUMBER :</strong> <?php echo htmlspecialchars($admin['phone_number']); ?></div>
    </div>
    <div class="profile-picture">
        <?php if (!empty($admin['profile_pic'])): ?>
            <img src="uploads/<?php echo htmlspecialchars($admin['profile_pic']); ?>" alt="Profile Picture">
        <?php else: ?>
            <p>Profile Picture</p>
        <?php endif; ?>
    </div>
    <button class="edit-button" onclick="openModal()">Edit</button>
</div>

<div class="modal-overlay" onclick="closeModal()"></div>
<div class="modal">
    <div class="modal-header">Edit Profile</div>
    <form action="update-profile.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="admin_id" value="<?php echo htmlspecialchars($admin_id); ?>">
        <label for="admin_name">Name:</label>
        <input type="text" name="admin_name" value="<?php echo htmlspecialchars($admin['admin_name']); ?>" required>

        <label for="phone_number">Phone Number:</label>
        <input type="text" name="phone_number" value="<?php echo htmlspecialchars($admin['phone_number']); ?>" required>

        <label for="profile_pic">Profile Picture:</label>
        <input type="file" name="profile_pic" accept="image/*">

        <button type="submit">Save</button>
    </form>
</div>

</body>
</html>
