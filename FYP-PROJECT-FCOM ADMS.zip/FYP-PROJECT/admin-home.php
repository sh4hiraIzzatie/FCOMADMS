<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home - FCOM ADMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body 
        {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        nav ul 
        {
            background-color: #4c8bf5;
            padding: 15px;
            list-style-type: none;
            margin: 0;
            text-align: center;
        }

        nav ul li 
        {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a 
        {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            margin: 40px auto;
            max-width: 800px;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h2 {
            color: #354a5f;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<header>
        <nav>
            <ul>
                <li><a href="admin-home.php">Home</a></li>
                <li><a href="manageAdmin.php">Admin</a></li>
                <li><a href="manageStudent.php">Student</a></li>
                <li><a href="manageSubject.php">Subject Management</a></li>
                <li><a href="faq-admin.php">FAQ</a></li>
                <li><a href="admin-login.php">Logout</a></li>
            </ul>
        </nav>
    </header>
        <main>
            <div class="dashboard">
                <div class="card">
                    <h3>Total Request</h3>
                    <p id="total-request">0</p>
                </div>
                <div class="card">
                    <h3>Total Pending ADS</h3>
                    <p id="total-rejected">0</p>
                </div>
                <div class="card">
                    <h3>Total Rejected ADS</h3>
                    <p id="total-pending">0</p>
                </div>
                <div class="card">
                    <h3>Total Approved ADS</h3>
                    <p id="total-approved">0</p>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
