<?php
session_start();
include("database.php");  // Include your database connection

// Query to get unique applications that are approved, grouped by student ID
$application_query = "
    SELECT studentld.student_name, add_drop_application.student_id, add_drop_application.status 
    FROM add_drop_application
    JOIN studentld ON add_drop_application.student_id = studentld.student_id
    WHERE add_drop_application.status = 'approved'
    GROUP BY add_drop_application.student_id";
$application_result = $con->query($application_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FCOM ADMS - Student Application List</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Roboto', sans-serif; }
        body { background-color: #f1f5f9; display: flex; flex-direction: column; align-items: center; color: #333; padding: 20px; }
        .header { width: 100%; background-color: #0d47a1; color: white; padding: 15px 20px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); border-radius: 8px; }
        .header h1 { font-size: 26px; font-weight: bold; margin: 0; }
        .header-nav a { color: white; text-decoration: none; font-size: 16px; font-weight: bold; margin-left: 20px; }
        .header-nav a:hover { text-decoration: underline; }
        .title { text-align: center; margin: 2rem 0 1.5rem; }
        .title h2 { font-size: 1.75rem; font-weight: 600; color: #333; border-bottom: 2px solid #ddd; display: inline-block; padding-bottom: 0.3rem; letter-spacing: 1px; }
        .search-container { display: flex; justify-content: center; gap: 10px; margin-bottom: 2rem; }
        .search-container input[type="text"] { padding: 0.6rem 1rem; width: 280px; border: 1px solid #ccc; border-radius: 20px; outline: none; font-size: 1rem; color: #333; }
        .search-container button { background-color: #0d47a1; color: white; border: none; border-radius: 20px; padding: 0.6rem 1.5rem; font-weight: 600; font-size: 1rem; cursor: pointer; transition: background-color 0.2s ease; }
        .search-container button:hover { background-color: #0a3a8c; }
        .table-container { width: 80%; margin-top: 20px; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background-color: white; border-radius: 8px; overflow: hidden; }
        table th, table td { padding: 15px; text-align: center; font-size: 16px; }
        th { background-color: #0d47a1; color: white; font-weight: bold; }
        tr:hover { background-color: #f1f5f9; }
        .open-button, .print-button { background-color: #5b73f2; color: white; border: none; border-radius: 12px; padding: 0.5rem 1.5rem; font-weight: bold; cursor: pointer; transition: background-color 0.2s; }
        .open-button:hover, .print-button:hover { background-color: #3a54e8; }
    </style>
</head>
<body>
    <div class="header">
        <h1>FCOM ADD DROP MANAGEMENT SYSTEM</h1>
        <div class="header-nav">
            <a href="bkrhome.php">Home</a>
            <a href="admin-login.php">Logout</a>
        </div>
    </div>

    <!-- Title -->
    <div class="title">
        <h2>Student Application List</h2>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Student ID</th>
                    <th>Application Details</th>
                    <th>Coordinator Approved</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($application_result->num_rows > 0): ?>
                    <?php while ($row = $application_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td>
                                <form action="openMS.php" method="GET">
                                    <input type="hidden" name="student_id" value="<?php echo htmlspecialchars($row['student_id']); ?>">
                                    <button type="submit" class="open-button">Open</button>
                                </form>
                            </td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">No approved applications found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
