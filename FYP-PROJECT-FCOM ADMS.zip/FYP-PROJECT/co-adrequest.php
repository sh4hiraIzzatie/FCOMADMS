<?php
session_start();
include("database.php");

// Initialize search variables
$searchStudentId = isset($_POST['student_id']) ? $_POST['student_id'] : '';
$searchStatus = isset($_POST['status']) ? $_POST['status'] : 'Pending';  // Default to 'Pending'

// Query to fetch distinct student IDs where applications are pending or as per search criteria
$query = "SELECT DISTINCT student_id, status FROM add_drop_application WHERE 1=1";
if (!empty($searchStudentId)) {
    $query .= " AND student_id LIKE '%$searchStudentId%'";
}
if (!empty($searchStatus)) {
    $query .= " AND status = '$searchStatus'";
}

// Execute query
$result = $con->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FCOM ADMS - Student Application List</title>
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Roboto', sans-serif;
    }

    body {
        background-color: #f1f5f9;
        display: flex;
        flex-direction: column;
        align-items: center;
        color: #333;
        padding: 20px;
    }

    /* Header Styling */
    .header {
            width: 100%;
            background-color: #0b0e33;
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 15px;
        }

        .logo1{
            width: 120px;
            height: 60px;
            margin: 0 5px;
        }

        .logo2{
            width: 115px;
            height: 80px;
            margin: 0 5px;
        }
    .header h1 {
        font-size: 26px;
        font-weight: bold;
    }

    .header-nav a {
        color: white;
        text-decoration: none;
        font-size: 16px;
        font-weight: bold;
        margin-left: 20px;
    }

    .header-nav a:hover {
        text-decoration: underline;
    }

    /* Title Styling */
    .title {
        text-align: center;
        margin: 2rem 0 1.5rem;
    }

    .title h2 {
        font-size: 1.75rem;
        font-weight: 600;
        color: #333;
        border-bottom: 2px solid #ddd;
        display: inline-block;
        padding-bottom: 0.3rem;
        letter-spacing: 1px;
    }

    /* Search Bar */
    .search-container {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-bottom: 2rem;
    }

    .search-container input[type="text"],
    .search-container select {
        padding: 0.6rem 1rem;
        border: 1px solid #ccc;
        border-radius: 20px;
        font-size: 1rem;
        color: #333;
    }

    .search-container button {
        background-color: #0d47a1;
        color: white;
        border: none;
        border-radius: 20px;
        padding: 0.6rem 1.5rem;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        transition: background-color 0.2s ease;
    }

    .search-container button:hover {
        background-color: #0a3a8c;
    }

    /* Table Container */
    .table-container {
        width: 80%;
        margin-top: 20px;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        background-color: white;
        border-radius: 8px;
    }

    table th, table td {
        padding: 15px;
        text-align: center;
        font-size: 16px;
    }

    th {
        background-color: #0d47a1;
        color: white;
        font-weight: bold;
    }

    tr:hover {
        background-color: #f1f5f9;
    }

    /* Button Styles */
    .open-button {
        background-color: #5b73f2;
        color: white;
        border: none;
        border-radius: 12px;
        padding: 0.5rem 1.5rem;
        font-weight: bold;
        cursor: pointer;
        transition: background-color 0.2s;
    }

    .open-button:hover {
        background-color: #3a54e8;
    }
    </style>
</head>
<body>
    <div class="header">
    <div class="logo-container">
        <img class="logo1" src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img class="logo2" src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
        <h1>FCOM ADD DROP MANAGEMENT SYSTEM</h1>
        <div class="header-nav">
            <a href="co-home.php">Home</a>
            <a href="co-login.php">Logout</a>
        </div>
    </div>

    <div class="title">
        <h2>Application List</h2>
    </div>

    <!-- Search Bar -->
    <div class="search-container">
        <form method="POST">
            <input type="text" name="student_id" placeholder="Search by Student ID" value="<?php echo htmlspecialchars($searchStudentId); ?>">
            <select name="status">
                <option value="Pending" <?php if ($searchStatus == 'Pending') echo 'selected'; ?>>Pending</option>
                <option value="Approved" <?php if ($searchStatus == 'Approved') echo 'selected'; ?>>Approved</option>
                <option value="Rejected" <?php if ($searchStatus == 'Rejected') echo 'selected'; ?>>Rejected</option>
            </select>
            <button type="submit">Search</button>
        </form>
    </div>

    <!-- Table -->
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                            <td>
                                <form action="co-openADR.php" method="GET" style="display:inline;">
                                    <button type="submit" class="open-button" name="student_id" value="<?php echo $row['student_id']; ?>">Open</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">No applications found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
