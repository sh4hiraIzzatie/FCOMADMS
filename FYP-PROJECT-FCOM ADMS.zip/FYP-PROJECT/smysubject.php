<?php
session_start();
include("database.php"); // Include your database connection here

// Fetch student ID from session
$student_id = $_SESSION['student_id'];

// Handle file upload for subject slip
if (isset($_FILES['subject_slip'])) {
    $file = $_FILES['subject_slip'];
    if ($file['type'] == 'application/pdf') {
        // Store the uploaded file (e.g., move it to a directory)
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        move_uploaded_file($file_tmp, "uploads/$file_name");

        // Example: You need to parse the PDF and extract the subjects here.
        // For now, let's assume this data comes from the PDF.
        $subjects = [
            ['code' => 'CS101', 'name' => 'Computer Science', 'credit_hours' => 3, 'section' => '1'],
            ['code' => 'MA101', 'name' => 'Mathematics', 'credit_hours' => 3, 'section' => '2'],
        ];

        // Insert extracted subjects into the database
        foreach ($subjects as $subject) {
            $subject_code = $subject['code'];
            $subject_name = $subject['name'];
            $credit_hours = $subject['credit_hours'];
            $section = $subject['section'];

            $insert_sql = "INSERT INTO existing_student_subject (student_id, subject_code, subject_name, credit_hours, section, source) 
                           VALUES ('$student_id', '$subject_code', '$subject_name', '$credit_hours', '$section', 'pdf')";
            mysqli_query($con, $insert_sql);
        }

        echo "<script>alert('Subject slip uploaded and subjects extracted successfully!');</script>";
    } else {
        echo "<script>alert('Please upload a valid PDF file.');</script>";
    }
}

// Handle manual entry of subjects
if (isset($_POST['manual_entry'])) {
    $subject_code = $_POST['subject_code'];
    $subject_name = $_POST['subject_name'];
    $credit_hours = $_POST['credit_hours'];
    $section = $_POST['section'];

    // Insert manually entered subject into the database
    $insert_sql = "INSERT INTO existing_student_subject (student_id, subject_code, subject_name, credit_hours, section, source) 
                   VALUES ('$student_id', '$subject_code', '$subject_name', '$credit_hours', '$section', 'manual')";
    mysqli_query($con, $insert_sql);

    echo "<script>alert('Subject successfully saved!');</script>";
}

// Fetch subject list from the database
$subject_sql = "SELECT * FROM existing_student_subject WHERE student_id = '$student_id'";
$subject_result = mysqli_query($con, $subject_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Subject List</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fb;
        }

        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .logo1{
            width: 80px;
            height: 45px;
            margin: 0 5px;
        }

        .logo2{
            width: 100px;
            height: 60px;
            margin: 0 5px;
        }

        /* Left-side navigation */
        .navbar {
            width: 220px;
            background-color: #0b0e33;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding: 20px;
            border-radius: 0 15px 15px 0;
            box-shadow: 2px 0 8px rgba(0,0,0,0.3);
        }

        .navbar a {
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #34495e;
        }

        h3 {
            font-size: 18px;
            color: #3893e8;
        }

        h1 {
            font-size: 26px;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
        }

        /* Enhanced container design */
        .container {
            margin-left: 250px;
            padding: 30px;
            min-height: 100vh;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 12px;
            margin-top: 20px;
        }

        .container h3 {
            font-size: 26px;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
        }

        /* Table design */
        table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table thead {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
        }

        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        /* Enhanced function box design */
        .function-box {
            margin: 20px;
            padding: 20px 40px;
            border: 2px solid #007bff;
            background-color: #fff;
            cursor: pointer;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            font-size: 16px;
            color: #007bff;
            font-weight: bold;
            transition: background-color 0.3s, color 0.3s;
        }

        .function-box:hover {
            background-color: #00ff59;
            color: #fff;
        }

        /* Enhanced popup design */
        .popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
        }

        .popup-content {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            position: relative;
            width: 450px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            animation: popupShow 0.4s ease-out;
        }

        @keyframes popupShow {
            from {
                transform: scale(0.8);
                opacity: 0;
            }
            to {
                transform: scale(1);
                opacity: 1;
            }
        }

        .popup-content h3 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #34495e;
        }

        .popup-content input, .popup-content button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .popup-content button {
            background-color: #3498db;
            color: #fff;
            cursor: pointer;
            border: none;
            transition: background-color 0.3s ease;
        }

        .popup-content button:hover {
            background-color: #2980b9;
        }

        .close {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 18px;
            cursor: pointer;
        }

    </style>
</head>
<body>

<div class="navbar">
    <div class="logo-container">
        <img class="logo1" src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img class="logo2" src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
    
    <h2>FCOM ADMS</h2>
    <h3>ACADEMIC</h3>
    <a href="studenthome.php">Home</a>
    <a href="smysubject.php">Subject Slip</a>
    <a href="studentads.php">Add/Drop</a>
    <h3>PROFILE</h3>
    <a href="studentprofile.php">Personal Information</a>
    <a href="student-login.php">Logout</a>
</div>

<div class="container">
    <h1>SUBJECT SLIP</h1>
    <table>
        <thead>
            <tr>
                <th>Subject Code</th>
                <th>Subject Name</th>
                <th>Credit Hours</th>
                <th>Section</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($subject_result)): ?>
                <tr>
                    <td><?= $row['subject_code']; ?></td>
                    <td><?= $row['subject_name']; ?></td>
                    <td><?= $row['credit_hours']; ?></td>
                    <td><?= $row['section']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Upload and manual entry boxes -->
    <div class="function-box" id="uploadSlipBtn">Upload Subject Slip (From CMS UPTM)</div>
    <div class="function-box" id="manualEntryBtn">Enter Subject Manually</div>
</div>

<!-- Popup for PDF Upload -->
<div id="uploadSlipPopup" class="popup">
    <div class="popup-content">
        <span class="close">&times;</span>
        <h3>Upload Subject Slip (PDF,JPEG,JPG)</h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="subject_slip" required>
            <button type="submit">Upload</button>
        </form>
    </div>
</div>

<!-- Popup for Manual Entry -->
<div id="manualEntryPopup" class="popup">
    <div class="popup-content">
        <span class="close">&times;</span>
        <h3>Enter Subject Manually</h3>
        <form method="POST">
            <input type="text" name="subject_code" placeholder="Subject Code" required>
            <input type="text" name="subject_name" placeholder="Subject Name" required>
            <input type="number" name="credit_hours" placeholder="Credit Hours" required>
            <input type="text" name="section" placeholder="Section" required>
            <button type="submit" name="manual_entry">Save Subject</button>
        </form>
    </div>
</div>

<script>
    // Show/Hide popup logic
    const uploadBtn = document.getElementById('uploadSlipBtn');
    const manualBtn = document.getElementById('manualEntryBtn');
    const closeBtns = document.querySelectorAll('.close');

    uploadBtn.addEventListener('click', () => {
        document.getElementById('uploadSlipPopup').style.display = 'flex';
    });

    manualBtn.addEventListener('click', () => {
        document.getElementById('manualEntryPopup').style.display = 'flex';
    });

    closeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            btn.closest('.popup').style.display = 'none';
        });
    });

    // Close popup when clicking outside the content
    window.addEventListener('click', function(e) {
        const uploadPopup = document.getElementById('uploadSlipPopup');
        const manualPopup = document.getElementById('manualEntryPopup');

        if (e.target === uploadPopup || e.target === manualPopup) {
            uploadPopup.style.display = 'none';
            manualPopup.style.display = 'none';
        }
    });
</script>

</body>
</html>
