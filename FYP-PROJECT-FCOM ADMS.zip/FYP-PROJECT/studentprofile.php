<?php
session_start();
include("database.php");

// Check if student_id is set in the session
if (!isset($_SESSION['student_id'])) {
    echo "Student ID not set in session. Please log in.";
    exit();
}

$student_id = $_SESSION['student_id'];

// Query the database for student details
$query = "SELECT student_name, ic_no, student_id, email, semester, session, active FROM studentld WHERE student_id = '$student_id'";
$result = mysqli_query($con, $query);

// Check if the query returned a result
if ($result && mysqli_num_rows($result) > 0) {
    $student = mysqli_fetch_assoc($result);
} else {
    echo "Student not found in the database.";
    exit();
}

// Set programme details
$programme_name = "BACHELOR OF INFORMATION TECHNOLOGY (HONOURS) IN COMPUTER APPLICATION DEVELOPMENT";
$programme_code = "CT204";

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Update student details
    $full_name = $_POST['full_name'];
    $ic_no = $_POST['ic_no'];
    $semester = $_POST['semester'];
    $session = $_POST['session'];

    // Validate IC No
    if (preg_match('/^\d{12}$/', $ic_no)) {
        // Update query
        $update_query = "UPDATE studentld SET student_name = '$full_name', ic_no = '$ic_no', semester = '$semester', session = '$session' WHERE student_id = '$student_id'";
        if (mysqli_query($con, $update_query)) {
            header('Location: studentprofile.php'); // Reload the page to display updated data
            exit();
        } else {
            $error_message = "Error updating student details.";
        }
    } else {
        // Invalid IC No
        $error_message = "IC No must be exactly 12 digits.";
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Student Profile</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script>
        function showEditPopup() {
            document.getElementById('edit-popup').style.display = 'block';
        }
        function closeEditPopup() {
            document.getElementById('edit-popup').style.display = 'none';
        }
    </script>
    <style>
        function showEditPopup() {
            document.getElementById('edit-popup').style.display = 'block';
        }
        function closeEditPopup() {
            document.getElementById('edit-popup').style.display = 'none';
        }

        {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fb;
        }

        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .logo1{
            width: 80px;
            height: 45px;
            margin: 0 5px;
        }

        .logo2{
            width: 100px;
            height: 60px;
            margin: 0 5px;
        }

        /* Left-side navigation */
        .navbar {
            width: 220px;
            background-color: #0b0e33;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding: 20px;
            border-radius: 0 15px 15px 0;
            box-shadow: 2px 0 8px rgba(0,0,0,0.3);
        }

        .navbar a {
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #34495e;
        }

        .container {
            display: flex;
        }

        h2 {
            color: #fff;
        }

        h3 {
            font-size: 18px;
            color: #3893e8;
        }

        .content {
            margin-left: 240px;
            padding: 40px;
        }

        .content h1 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        /* Rounded profile-info section */
        .profile-info {
            background-color: white;
            padding: 20px;
            border-radius: 15px; /* Rounds the profile info box */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .edit-button 
        {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff; /* Blue background */
            color: white; /* White text */
            font-size: 16px; /* Font size */
            cursor: pointer; /* Pointer cursor on hover */
            transition: background-color 0.3s ease; /* Smooth transition */
            margin-top: 20px; /* Add top margin for spacing */
        }

        .edit-button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        /* Popup design */
        .popup {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 600px; /* Adjusted width for a larger popup */
            background: white;
            padding: 40px;
            border-radius: 20px; /* Rounds the popup box */
            box-shadow: 0 15px 25px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }

        .popup h3 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #2c3e50;
        }

        .popup label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        .popup input[type="text"],
        .popup select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 10px; /* Rounds the input fields */
            font-size: 16px;
        }

        .save-button,
        .cancel-button {
            background-color: #2ecc71;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 10px; /* Rounds the buttons */
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }

        .cancel-button {
            background-color: #e74c3c;
            margin-left: 10px;
        }

        .save-button:hover {
            background-color: #27ae60;
        }

        .cancel-button:hover {
            background-color: #c0392b;
        }

        .popup-buttons {
            display: flex;
            justify-content: flex-end;
        }

        .popup-buttons button {
            margin-left: 10px;
        }

    </style>
</head>
<body>

<div class="navbar">
    <!-- Logos displayed side by side -->
    <div class="logo-container">
        <img class="logo1" src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img class="logo2" src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
    
    <!-- Navigation links -->
    <h2>FCOM ADMS</h2>
    <h3>ACADEMIC</h3>
    <a href="studenthome.php">Info</a>
    <a href="student-appslip.php">Application Slip</a>
    <a href="student-adddrop.php">Add/Drop</a>
    <h3>PROFILE</h3>
    <a href="studentprofile.php">Personal Information</a>
    <a href="faq-student.php">FAQ</a>
    <a href="student-login.php">Logout</a>
</div>

    <div class="content">
        <h1><?php echo htmlspecialchars($student['student_name']); ?>'s Profile</h1>
        
        <?php if (isset($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <div class="profile-info">
            <p><strong>Full Name:</strong> <?php echo htmlspecialchars($student['student_name']); ?></p>
            <p><strong>IC No:</strong> <?php echo htmlspecialchars($student['ic_no']); ?></p>
            <p><strong>Student ID:</strong> <?php echo htmlspecialchars($student['student_id']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></p>
            <p><strong>Programme Name:</strong> <?php echo htmlspecialchars($programme_name); ?></p>
            <p><strong>Programme Code:</strong> <?php echo htmlspecialchars($programme_code); ?></p>
            <p><strong>Semester:</strong> <?php echo htmlspecialchars($student['semester']); ?></p>
            <p><strong>Session:</strong> <?php echo htmlspecialchars($student['session']); ?></p>
            <p><strong>Active:</strong> <?php echo $student['active'] === 'Y' ? 'Yes' : 'No'; ?></p>

            <button class="edit-button" onclick="showEditPopup()">Edit</button>
        </div>

        <!-- Edit Popup -->
        <div id="edit-popup" class="popup" style="display: none;">
            <h3>Edit Student Information</h3>
            <form method="POST" action="studentprofile.php">
                <label for="full_name">Full Name:</label>
                <input type="text" name="full_name" value="<?php echo htmlspecialchars($student['student_name']); ?>" required>

                <label for="ic_no">IC No:</label>
                <input type="text" name="ic_no" value="<?php echo htmlspecialchars($student['ic_no']); ?>" required>

                <label for="semester">Semester:</label>
                <input type="text" name="semester" value="<?php echo htmlspecialchars($student['semester']); ?>" required>

                <label for="session">Session:</label>
                <input type="text" name="session" value="<?php echo htmlspecialchars($student['session']); ?>" required>

                <div class="popup-buttons">
                    <button type="submit" class="save-button">Save</button>
                    <button type="button" class="cancel-button" onclick="closeEditPopup()">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>


