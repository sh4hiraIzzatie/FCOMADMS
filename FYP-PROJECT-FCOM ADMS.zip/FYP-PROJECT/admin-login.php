<?php
session_start();
include("database.php");

$error_message = '';

if (isset($_POST['login'])) {
    $user_id = $_POST['user_id'];
    $password = $_POST['password']; 

    // Check login credentials
    $stmt = $con->prepare("SELECT * FROM bkrld WHERE user_id = ? AND password = ?");
    $stmt->bind_param("ss", $user_id, $password);
    $stmt->execute();
    $result = $stmt->get_result();

if ($result->num_rows > 0) {
        $_SESSION['user_id'] = $user_id; 
        header("Location: bkrhome.php?login=success");
        exit();
    } else {
        $error_message = "Invalid User ID or Password.";
    }

    $stmt->close();
    $con->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - FCOM ADMS</title>

    <style>
       body {
            font-family: 'Arial', sans-serif;
            background-image: url('img/uptmblur.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }

        .login-container {
            position: relative;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            border-radius: 12px;
            width: 400px;
            text-align: center;
            z-index: 2;
        }

        .login-container:hover {
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.3);
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
            font-weight: 600;
        }

        .logo-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .logo-container img {
            width: 80px;
            height: auto;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: center;
        }

        input[type="text"],
        input[type="password"] {
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            width: 80%;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #007bff;
            outline: none;
        }

        button[type="submit"] {
            padding: 12px;
            font-size: 16px;
            background-color: #007bff;
            background-image: linear-gradient(to right, #007bff, #0056b3);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            width: 60%;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
            background-image: linear-gradient(to right, #0056b3, #004085);
            transform: translateY(-2px);
        }

        button[type="submit"]:active {
            transform: translateY(1px);
        }

        .register-link a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        .footer {
            margin-top: 20px;
            font-size: 12px;
            color: #777;
        }

        .error-message {
            color: red;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Admin Login</h1>
        <h2>BKR</h2>

        <form action="bkrhome.php" method="POST">
            <label for="user_id">User ID:</label>
            <input type="text" id="user_id" name="user_id" required>
                
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit">Login</button>
        </form>

        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <div class="footer">
            &copy; 2024 FCOM Add Drop Management System.
        </div>
    </div>    
    
</body>
</html>
