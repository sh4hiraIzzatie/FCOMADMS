// Get elements
const uploadSlipBtn = document.getElementById('uploadSlipBtn');
const manualEntryBtn = document.getElementById('manualEntryBtn');
const uploadSlipPopup = document.getElementById('uploadSlipPopup');
const manualEntryPopup = document.getElementById('manualEntryPopup');
const closeBtns = document.querySelectorAll('.close');

// Show upload popup
uploadSlipBtn.addEventListener('click', () => {
    uploadSlipPopup.style.display = 'flex';
});

// Show manual entry popup
manualEntryBtn.addEventListener('click', () => {
    manualEntryPopup.style.display = 'flex';
});

// Close popups
closeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        uploadSlipPopup.style.display = 'none';
        manualEntryPopup.style.display = 'none';
    });
});
