<?php
session_start();
include("database.php");

// Get the student ID from the session
$student_id = $_SESSION['student_id'];

// Fetch the student's active status from the database
$query_active_status = "SELECT active FROM studentld WHERE student_id = '$student_id'";
$result_active_status = $con->query($query_active_status);
$student_status = $result_active_status->fetch_assoc();
$is_active = $student_status['active'] === 'Y';

// Fetch the subjects the student is enrolled in
$query_existing_subjects = "SELECT subject_code FROM student_subjects WHERE student_id = '$student_id'";
$result_existing_subjects = $con->query($query_existing_subjects);
$existing_subjects = [];
while ($row = $result_existing_subjects->fetch_assoc()) {
    $existing_subjects[] = $row['subject_code'];
}

// Fetch all available subjects from the database
$query = "SELECT subject_name, subject_code, credit_hours, subject_section FROM subjects";
$result_subjects = $con->query($query);

// Check if there is a pending add/drop application
$query_pending_application = "SELECT COUNT(*) as pending_count FROM add_drop_applications WHERE student_id = '$student_id' AND status = 'pending'";
$result_pending_application = $con->query($query_pending_application);
$pending_application = $result_pending_application->fetch_assoc()['pending_count'] > 0;

// Handle form submission for add/drop subjects
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_active) {
    // Retrieve selected subjects to add or drop from the form
    $subjects_to_add = isset($_POST['subjects_to_add']) ? $_POST['subjects_to_add'] : [];
    $subjects_to_drop = isset($_POST['subjects_to_drop']) ? $_POST['subjects_to_drop'] : [];

    // Insert data for subjects to add
    foreach ($subjects_to_add as $subject_code) {
        $action = 'add';
        $query = "INSERT INTO add_drop_applications (student_id, subject_code, action, status) 
                  VALUES ('$student_id', '$subject_code', '$action', 'pending')";
        if ($con->query($query) === TRUE) {
            echo "Subject added: $subject_code<br>";
        } else {
            echo "Error adding subject: $subject_code<br>" . $con->error;
        }
    }

    // Insert data for subjects to drop
    foreach ($subjects_to_drop as $subject_code) {
        $action = 'drop';
        $query = "INSERT INTO add_drop_applications (student_id, subject_code, action, status) 
                  VALUES ('$student_id', '$subject_code', '$action', 'pending')";
        if ($con->query($query) === TRUE) {
            echo "Subject dropped: $subject_code<br>";
        } else {
            echo "Error dropping subject: $subject_code<br>" . $con->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Add/Drop Subjects</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f9fb;
            margin: 0;
            padding: 0;
        }
        
        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .logo1{
            width: 80px;
            height: 45px;
            margin: 0 5px;
        }

        .logo2{
            width: 100px;
            height: 60px;
            margin: 0 5px;
        }

        /* Left-side navigation */
        .navbar {
            width: 220px;
            background-color: #0b0e33;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding: 20px;
            border-radius: 0 15px 15px 0;
            box-shadow: 2px 0 8px rgba(0,0,0,0.3);
        }

        .navbar a {
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #34495e;
        }

        h3 {
            font-size: 18px;
            color: #3893e8;
        }
        

        .container {
            margin-left: 250px;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 12px;
            margin-top: 20px;
        }

        .container h1 {
            font-size: 26px;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
        }

        table th, table td {
            padding: 15px;
            text-align: center;
            font-size: 16px;
        }

        th {
            background-color: #0d47a1;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:hover {
            background-color: #f1f5f9;
        }

        .submit-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        .popup-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            justify-content: center;
            align-items: center;
        }

        .popup-box {
            width: 50%;
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
            text-align: center;
        }

        .popup-box h3 {
            color: #333;
            margin-bottom: 10px;
        }

        .popup-box p {
            font-size: 18px;
            color: #555;
        }

        .popup-box button {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .popup-box button:hover {
            background-color: #0056b3;
        }
        
        /* Styles for the notification box */
        .notification-box {
            width: 90%;
            margin: 20px auto;
            padding: 15px;
            background-color: #e8f0fe;
            border: 1px solid #b0c4de;
            border-radius: 8px;
            text-align: center;
            font-size: 18px;
        }
        .notification-box.error {
            background-color: #fdecea;
            border-color: #f5c6cb;
            color: #a94442;
        }
        .notification-box.success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>ADD/DROP APPLICATION</h1>

    <?php if ($is_active): ?>
        <div class="notification-box success">
            Your account is active.
        </div>
    <?php else: ?>
        <div class="notification-box error">
            Your account is inactive. Please refer to the BKR.
        </div>
    <?php endif; ?>

    <?php if ($pending_application): ?>
        <div class="notification-box">
            Your application is still in process.
        </div>
    <?php endif; ?>

    <?php if ($is_active && !$pending_application): ?>
        <form id="subjectForm" method="post" action="">
            <table>
                <tr>
                    <th>Subject Name</th>
                    <th>Subject Code</th>
                    <th>Credit Hours</th>
                    <th>Section</th>
                    <th>Action</th>
                </tr>
                <?php while ($row_subject = $result_subjects->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row_subject['subject_name']; ?></td>
                        <td><?php echo $row_subject['subject_code']; ?></td>
                        <td><?php echo $row_subject['credit_hours']; ?></td>
                        <td><?php echo $row_subject['subject_section']; ?></td>
                        <td>
                            <?php if (in_array($row_subject['subject_code'], $existing_subjects)): ?>
                                <input type="checkbox" name="subjects_to_drop[]" value="<?php echo $row_subject['subject_code']; ?>"> Drop
                            <?php else: ?>
                                <input type="checkbox" name="subjects_to_add[]" value="<?php echo $row_subject['subject_code']; ?>"> Add
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>

            <div style="margin-top: 20px;">
                <input type="checkbox" id="declaration" onclick="toggleSubmitButton()">
                <label for="declaration">I would like to add/drop courses mentioned above. Failure to register may affect my programme enrolment and examination.</label>
            </div>

            <button type="button" class="submit-btn" id="submitButton" onclick="showConfirmationPopup()" disabled>Submit</button>
        </form>
    <?php endif; ?>
</div>

<div class="popup-overlay" id="popupOverlay">
    <div class="popup-box">
        <h3>Confirm Your Selection</h3>
        <p id="popupMessage"></p>
        <button onclick="closePopup(true)">Confirm</button>
        <button onclick="closePopup(false)">Cancel</button>
    </div>
</div>

<script>
    function toggleSubmitButton() {
        var declarationCheckbox = document.getElementById("declaration");
        var submitButton = document.getElementById("submitButton");
        submitButton.disabled = !declarationCheckbox.checked;
    }

    function showConfirmationPopup() {
        var addSubjects = [];
        var dropSubjects = [];

        document.querySelectorAll("input[name='subjects_to_add[]']:checked").forEach(function (input) {
            addSubjects.push(input.value);
        });
        document.querySelectorAll("input[name='subjects_to_drop[]']:checked").forEach(function (input) {
            dropSubjects.push(input.value);
        });

        var popup = document.getElementById("popupOverlay");
        var popupMessage = document.getElementById("popupMessage");

        popupMessage.innerHTML = "<strong>Subjects to Add:</strong> " + addSubjects.join(", ") + "<br><br><strong>Subjects to Drop:</strong> " + dropSubjects.join(", ");
        popup.style.display = "flex";
    }

    function closePopup(confirm) {
        var popup = document.getElementById("popupOverlay");
        if (confirm) {
            document.getElementById("subjectForm").submit();
        }
        popup.style.display = "none";
    }
</script>
</body>
</html>
