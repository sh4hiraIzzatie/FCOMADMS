<?php
session_start();
include 'database.php';

// Fetch total counts for add/drop applications
$total_sql = "SELECT COUNT(*) as total_applications FROM add_drop_applications";
$total_result = mysqli_query($con, $total_sql);
$total_applications = mysqli_fetch_assoc($total_result)['total_applications'];

// Fetch successful applications
$successful_sql = "SELECT COUNT(*) as successful_applications FROM add_drop_applications WHERE application_status = 'successful'";
$successful_result = mysqli_query($con, $successful_sql);
$successful_applications = mysqli_fetch_assoc($successful_result)['successful_applications'];

// Fetch pending applications
$pending_sql = "SELECT COUNT(*) as pending_applications FROM add_drop_applications WHERE application_status = 'pending'";
$pending_result = mysqli_query($con, $pending_sql);
$pending_applications = mysqli_fetch_assoc($pending_result)['pending_applications'];

// Fetch rejected applications
$rejected_sql = "SELECT COUNT(*) as rejected_applications FROM add_drop_applications WHERE application_status = 'rejected'";
$rejected_result = mysqli_query($con, $rejected_sql);
$rejected_applications = mysqli_fetch_assoc($rejected_result)['rejected_applications'];

// Fetch all subjects (this is part of your current manageSubject.php functionality)
$sql = "SELECT * FROM add_drop_applications";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subject</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Add some basic styling for the statistics section */
        .stats-container {
            margin: 20px 0;
            display: flex;
            justify-content: space-between;
            text-align: center;
        }

        .stat-box {
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 8px;
            width: 23%;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .stat-box h3 {
            margin: 0;
            color: #354a5f;
        }

        .stat-box p {
            font-size: 20px;
            margin: 10px 0;
            color: #354a5f;
        }
    </style>
</head>
<body>
    <nav>
        <ul>
            <li><a href="admin-home.php">Home</a></li>
            <li><a href="manageAdmin.php">Manage Admin</a></li>
            <li><a href="manageStudent.php">Manage Students</a></li>
            <li><a href="manageSubject.php">Manage Subjects</a></li>
        </ul>
    </nav>
    <main>
        <h2>Manage Subjects</h2>

        <!-- Statistics for add/drop applications -->
        <div class="stats-container">
            <div class="stat-box">
                <h3>Total Applications</h3>
                <p><?php echo $total_applications; ?></p>
            </div>
            <div class="stat-box">
                <h3>Successful</h3>
                <p><?php echo $successful_applications; ?></p>
            </div>
            <div class="stat-box">
                <h3>Pending</h3>
                <p><?php echo $pending_applications; ?></p>
            </div>
            <div class="stat-box">
                <h3>Rejected</h3>
                <p><?php echo $rejected_applications; ?></p>
            </div>
        </div>

        <!-- Add Subject Form -->
        <h2>Add New Subject</h2>
        <form method="POST" action="">
            <label for="subject_name">Subject Name:</label>
            <input type="text" name="subject_name" required>
            
            <label for="subject_code">Subject Code:</label>
            <input type="text" name="subject_code" required>
            
            <label for="credit_hours">Credit Hours:</label>
            <select name="credit_hours" required>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>
            
            <label for="contact_hours">Contact Hours:</label>
            <select name="contact_hours" required>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>
            
            <label for="subject_session">Subject Session:</label>
            <input type="text" name="subject_session" required>
            
            <label for="subject_section">Subject Section:</label>
            <select name="subject_section" required>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
            </select>
            
            <input type="submit" name="create_subject" value="Add Subject">
        </form>

        <!-- List of Subjects -->
        <h2>List of Subjects</h2>
        <table>
            <thead>
                <tr>
                    <th>Subject Name</th>
                    <th>Subject Code</th>
                    <th>Credit Hours</th>
                    <th>Contact Hours</th>
                    <th>Session</th>
                    <th>Section</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $row['subject_name']; ?></td>
                        <td><?php echo $row['subject_code']; ?></td>
                        <td><?php echo $row['credit_hours']; ?></td>
                        <td><?php echo $row['contact_hours']; ?></td>
                        <td><?php echo $row['subject_session']; ?></td>
                        <td><?php echo $row['subject_section']; ?></td>
                        <td>
                            <!-- Add edit button (edit functionality can be added here) -->
                            <a href="#">Edit</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</body>
</html>
