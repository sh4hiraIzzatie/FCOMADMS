<?php
session_start();
include("database.php");

if (isset($_GET['student_id'])) {
    $studentId = $_GET['student_id'];

    // Fetch all student details from the studentld table
    $studentQuery = "SELECT student_name, ic_no, student_id, email, programme_name, programme_code, semester, session, active FROM studentld WHERE student_id = ?";
    $studentStmt = $con->prepare($studentQuery);
    $studentStmt->bind_param('s', $studentId);
    $studentStmt->execute();
    $studentResult = $studentStmt->get_result();
    $student = $studentResult->fetch_assoc();
    $studentStmt->close();

    // Fetch all add/drop requests for the specified student
    $requestQuery = "SELECT * FROM add_drop_application WHERE student_id = ?";
    $requestStmt = $con->prepare($requestQuery);
    $requestStmt->bind_param('s', $studentId);
    $requestStmt->execute();
    $requestResult = $requestStmt->get_result();
} else {
    echo "Student ID not provided.";
    exit;
}

// Update status for all requests if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $status = ($action === 'Approve') ? 'approved' : 'rejected';  // Use lowercase consistently
    $reject_reason = isset($_POST['reject_reason']) ? $_POST['reject_reason'] : null;

    if ($action === 'Reject' && $reject_reason) {
        // Update status, action, and rejection reason for all applications of the student
        $stmt = $con->prepare("UPDATE add_drop_application SET status = ?, action = ?, reject_reason = ? WHERE student_id = ?");
        $stmt->bind_param('ssss', $status, $action, $reject_reason, $studentId);
    } else {
        // Update status and action only for approved applications
        $stmt = $con->prepare("UPDATE add_drop_application SET status = ?, action = ? WHERE student_id = ?");
        $stmt->bind_param('sss', $status, $action, $studentId);
    }

    if ($stmt->execute()) {
        $message = "All applications have been " . strtolower($status) . " successfully.";
    } else {
        $message = "Error updating applications: " . $con->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CO-Student Add/Drop Approval</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Roboto', sans-serif; }
        body { background-color: #f1f5f9; display: flex; flex-direction: column; align-items: center; color: #333; padding: 20px; }
        /* Header Styling */
    .header {
            width: 100%;
            background-color: #0b0e33;
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 15px;
        }

        .logo1{
            width: 120px;
            height: 60px;
            margin: 0 5px;
        }

        .logo2{
            width: 115px;
            height: 80px;
            margin: 0 5px;
        }
        .header h1 { font-size: 26px; font-weight: bold; margin: 0; }
        .header-nav a { color: white; text-decoration: none; font-size: 16px; font-weight: bold; margin-left: 20px; }
        .header-nav a:hover { text-decoration: underline; }
        .student-details { background-color: #F1F1F1; padding: 20px; margin: 20px; border-radius: 8px; }
        .request-section { margin: 20px; }
        .sdetails-container, .table-container { width: 80%; margin-top: 20px; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background-color: white; border-radius: 8px; overflow: hidden; }
        table th, table td { padding: 15px; text-align: center; font-size: 16px; }
        th { background-color: #0d47a1; color: white; font-weight: bold; }
        tr:hover { background-color: #f1f5f9; }
        .approve-button, .reject-button { border: none; border-radius: 12px; padding: 0.5rem 1.5rem; font-weight: bold; cursor: pointer; transition: background-color 0.2s; margin-right: 10px; }
        .approve-button { background-color: #28A745; color: white; }
        .approve-button:hover { background-color: #218838; }
        .reject-button { background-color: #e53935; color: white; }
        .reject-button:hover { background-color: #d32f2f; }
        .modal { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); z-index: 1000; width: 300px; }
        .modal h3 { color: #e53935; margin-bottom: 15px; text-align: center; }
        .modal select, .modal button { margin-top: 10px; padding: 10px; border-radius: 8px; border: 1px solid #ddd; width: 100%; font-size: 14px; }
        .modal button { background-color: #4caf50; color: white; cursor: pointer; }
        .modal button:hover { background-color: #45a049; }
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); z-index: 999; }
    </style>
    <script>
        function openRejectModal() {
            document.getElementById('modal-overlay').style.display = 'block';
            document.getElementById('reject-modal').style.display = 'block';
        }

        function closeRejectModal() {
            document.getElementById('modal-overlay').style.display = 'none';
            document.getElementById('reject-modal').style.display = 'none';
        }

        function notifyStudent() {
            alert('Rejection reason has been sent to the student.');
            closeRejectModal();
        }
    </script>
</head>
<body>
<div class="header">
<div class="logo-container">
        <img class="logo1" src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img class="logo2" src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
    <h1>FCOM ADD DROP MANAGEMENT SYSTEM</h1>
    <div class="header-nav">
        <a href="co-adrequest.php">Back</a>
    </div>
</div>

<div class="sdetails-container">
    <div class="student-details">
        <p><strong>STUDENT DETAILS</strong></p>
        <?php if (isset($student)): ?>
            <p><strong>Full Name:</strong> <?php echo htmlspecialchars($student['student_name']); ?></p>
            <p><strong>IC No:</strong> <?php echo htmlspecialchars($student['ic_no']); ?></p>
            <p><strong>Student ID:</strong> <?php echo htmlspecialchars($student['student_id']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></p>
            <p><strong>Programme Name:</strong> <?php echo htmlspecialchars($student['programme_name']); ?></p>
            <p><strong>Programme Code:</strong> <?php echo htmlspecialchars($student['programme_code']); ?></p>
            <p><strong>Semester:</strong> <?php echo htmlspecialchars($student['semester']); ?></p>
            <p><strong>Session:</strong> <?php echo htmlspecialchars($student['session']); ?></p>
            <p><strong>Active:</strong> <?php echo $student['active'] === 'Y' ? 'Yes' : 'No'; ?></p>
        <?php else: ?>
            <p>No student details found.</p>
        <?php endif; ?>
    </div>
</div>

<div class="table-container">
    <div class="request-section">
        <h2>REQUESTS</h2>
        <?php if (isset($message)) echo "<p>$message</p>"; ?>
        <table>
            <thead>
                <tr>
                    <th>Subject Name</th>
                    <th>Subject Code</th>
                    <th>Credit Hours</th>
                    <th>Section</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($requestResult && $requestResult->num_rows > 0): ?>
                    <?php while ($row = $requestResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['subject_code']); ?></td>
                            <td><?php echo htmlspecialchars($row['credit_hours']); ?></td>
                            <td><?php echo htmlspecialchars($row['subject_section']); ?></td>
                            <td><?php echo htmlspecialchars($row['action']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">No applications found for this student.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <!-- Approve/Reject all requests -->
        <form method="POST" style="margin-top: 20px;">
            <input type="hidden" name="student_id" value="<?php echo $studentId; ?>">
            <button type="submit" name="action" value="Approve" class="approve-button">APPROVE</button>
            <button type="button" onclick="openRejectModal()" class="reject-button">REJECT</button>
        </form>
    </div>
</div>

<!-- Modal Overlay -->
<div id="modal-overlay" class="modal-overlay" onclick="closeRejectModal()"></div>

<!-- Reject Modal -->
<div id="reject-modal" class="modal">
    <form method="POST">
        <input type="hidden" name="action" value="Reject">
        <h3>REJECT APPLICATIONS</h3>
        <select name="reject_reason" required>
            <option value="Please find the coordinator">Please find the coordinator</option>
            <option value="Subject cannot be taken this semester">Subject cannot be taken this semester</option>
            <option value="Your status is not active">Your status is not active</option>
        </select>
        <button type="submit" onclick="notifyStudent()">NOTIFY STUDENT</button>
    </form>
</div>

</body>
</html>