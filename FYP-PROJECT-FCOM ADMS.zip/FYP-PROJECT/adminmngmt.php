<?php
session_start();
include 'database.php';

// Create Admin
if (isset($_POST['create_admin'])) {
    $admin_id = $_POST['admin_id'];
    $admin_name = $_POST['admin_name'];
    $admin_email = $_POST['admin_email'];
    $admin_password = $_POST['admin_password']; // Store as plain text

    // Check if the admin_id already exists
    $check_sql = "SELECT * FROM managea WHERE admin_id = '$admin_id'";
    $check_result = mysqli_query($con, $check_sql);
    if (mysqli_num_rows($check_result) > 0) {
        header("Location: adminmngmt.php?message=Admin ID already exists&type=error");
        exit();
    }

    // Insert new admin
    $sql = "INSERT INTO managea (admin_id, admin_name, admin_email, admin_password) 
            VALUES ('$admin_id', '$admin_name', '$admin_email', '$admin_password')";
    if (mysqli_query($con, $sql)) {
        header("Location: adminmngmt.php?message=Admin created successfully&type=success");
    } else {
        header("Location: adminmngmt.php?message=Error creating admin&type=error");
    }
    exit();
}

// Delete Admin
if (isset($_GET['delete_admin'])) {
    $admin_id = $_GET['delete_admin'];
    $sql = "DELETE FROM managea WHERE admin_id = '$admin_id'";
    if (mysqli_query($con, $sql)) {
        header("Location: adminmngmt.php?message=Admin deleted successfully&type=success");
    } else {
        header("Location: adminmngmt.php?message=Error deleting admin&type=error");
    }
    exit();
}

// Search Admin
$search_query = '';
if (isset($_GET['search_query'])) {
    $search_query = $_GET['search_query'];
    $sql = "SELECT * FROM managea WHERE admin_id LIKE '%$search_query%' OR 
                                      admin_name LIKE '%$search_query%' OR 
                                      admin_email LIKE '%$search_query%'";
} else {
    // Fetch all admins from the database
    $sql = "SELECT * FROM managea";
}

$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color: #f1f5f9;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #333;
            padding: 20px;
        }

        /* Enhanced Header Styling */
        .header {
            width: 100%;
            background-color: #0d47a1;
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .header h1 {
            font-size: 26px;
            font-weight: bold;
            margin: 0;
        }

        .header-nav a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            margin-left: 20px;
        }

        .header-nav a:hover {
            text-decoration: underline;
        }

        /* Admin Section */
        .admin-section {
            width: 80%;
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        }

        .admin-section h2 {
            text-align: center;
            font-size: 1.6rem;
            margin-bottom: 20px;
            color: #0d47a1;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        form label {
            width: 100%;
            margin-bottom: 8px;
            text-align: left;
            font-weight: bold;
            color: #333;
        }

        input[type="text"],
        input[type="password"],
        input[type="email"],
        input[type="search"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 25px;
            outline: none;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus,
        input[type="email"]:focus,
        input[type="search"]:focus {
            border-color: #4c8bf5;
            box-shadow: 0 0 5px rgba(76, 139, 245, 0.5);
        }

        input[type="submit"] {
            padding: 12px 25px;
            background-color: #4c8bf5;
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s;
            font-weight: bold;
            margin-top: 10px;
        }

        input[type="submit"]:hover {
            background-color: #3b6fbc;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(59, 111, 188, 0.3);
        }

        /* Add space between create button and search section */
        .admin-section form + h2 {
            margin-top: 30px;
        }

        /* Enhanced Search Styling */
        .search-container {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            position: relative;
            width: 320px;
        }

        .search-container input[type="text"] {
            padding: 12px 20px 12px 45px;
            font-size: 16px;
            border: 2px solid #0d47a1;
            border-radius: 25px;
            width: 100%;
            outline: none;
            transition: border-color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .search-container input[type="text"]::placeholder {
            color: #888;
        }

        .search-container input[type="text"]:focus {
            border-color: #1a73e8;
            box-shadow: 0 4px 8px rgba(26, 115, 232, 0.2);
        }

        .search-container button {
            position: absolute;
            right: 5px;
            top: 5px;
            padding: 8px 16px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            background-color: #1a73e8;
            color: white;
            cursor: pointer;
            border-radius: 25px;
            transition: background-color 0.3s;
        }

        .search-container button:hover {
            background-color: #0c47a1;
        }

        .search-container .search-icon {
            position: absolute;
            left: 15px;
            top: 12px;
            font-size: 18px;
            color: #888;
        }

        .table-container {
            width: 80%;
            margin-top: 20px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
        }

        table th, table td {
            padding: 15px;
            text-align: center;
            font-size: 16px;
        }

        th {
            background-color: #0d47a1;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:hover {
            background-color: #f1f5f9;
        }

        .delete-btn {
            background-color: #ff5c5c;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-weight: bold;
            margin-right: 10px;
        }

        .delete-btn:hover {
            background-color: #e04b4b;
        }

        /* Additional Styles */
        .open-btn {
            background-color: #4c8bf5;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-weight: bold;
            margin-right: 10px;
        }

        .open-btn:hover {
            background-color: #3b6fbc;
        }

        .popup-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            justify-content: center;
            align-items: center;
        }

        .popup-box {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 300px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
            position: relative;
        }

        .popup-box h3 {
            margin-bottom: 10px;
        }

        .popup-box p {
            margin-bottom: 15px;
            font-size: 14px;
            color: #333;
        }

        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            color: #666;
        }

        .close-btn:hover {
            color: #333;
        }

            /* Notification Styles */
        .notification {
            background-color: #4caf50;
            color: white;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            margin-top: 10px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>FCOM ADD DROP MANAGEMENT SYSTEM</h1>
        <div class="header-nav">
            <a href="bkrhome.php">Home</a>
            <a href="admin-login.php">Logout</a>
        </div>
    </div>

    <div class="admin-section">
        <h2>Create Admin</h2>
        <form action="adminmngmt.php" method="POST">
            <label for="admin_id">Admin ID:</label>
            <input type="text" id="admin_id" name="admin_id" required>
            
            <label for="admin_name">Admin Name:</label>
            <input type="text" id="admin_name" name="admin_name" required>
            
            <label for="admin_email">Admin Email:</label>
            <input type="email" id="admin_email" name="admin_email" required>
            
            <label for="admin_password">Password:</label>
            <input type="password" id="admin_password" name="admin_password" required>
            
            <input type="submit" name="create_admin" value="Create Admin">
        </form>


        <h2>Search Admin</h2>
        <form action="adminmngmt.php" method="GET" class="form-section">
            <input type="search" name="search_query" placeholder="Search by ID, Name, Email" required>
            <i class="fas fa-search search-icon"></i> <!-- Search icon added here -->
        </form>
    </div>

    <div class="table-container">
        <table>
            <tr>
                <th>Admin ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td><?= $row['admin_id'] ?></td>
                    <td><?= $row['admin_name'] ?></td>
                    <td><?= $row['admin_email'] ?></td>
                    <td>
                        <button class="open-btn" onclick="openPopup('<?= $row['admin_id'] ?>', '<?= $row['admin_name'] ?>', '<?= $row['admin_email'] ?>')">Open</button>
                        <a href="adminmngmt.php?delete_admin=<?= $row['admin_id'] ?>" class="delete-btn">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <!-- Popup Structure -->
    <div id="popupOverlay" class="popup-overlay">
        <div class="popup-box">
            <button class="close-btn" onclick="closePopup()">&times;</button>
            <h3>Admin Information</h3>
            <p><strong>ID:</strong> <span id="popupAdminID"></span></p>
            <p><strong>Name:</strong> <span id="popupAdminName"></span></p>
            <p><strong>Email:</strong> <span id="popupAdminEmail"></span></p>
        </div>
    </div>

    <!-- JavaScript for Popup -->
    <script>
        function openPopup(adminID, adminName, adminEmail) {
            document.getElementById('popupAdminID').textContent = adminID;
            document.getElementById('popupAdminName').textContent = adminName;
            document.getElementById('popupAdminEmail').textContent = adminEmail;

            document.getElementById('popupOverlay').style.display = 'flex';
        }

        function closePopup() {
            document.getElementById('popupOverlay').style.display = 'none';
        }
    </script>
</body>
</html>
