<?php
session_start();
include("database.php"); // Include your database connection

// Get student ID from the URL
$studentId = $_GET['student_id'] ?? null;


// Fetch student details
$studentQuery = "SELECT student_name, ic_no, student_id, email, programme_name, programme_code, semester, session, active FROM studentld WHERE student_id = ?";
$studentStmt = $con->prepare($studentQuery);
$studentStmt->bind_param('s', $studentId);
$studentStmt->execute();
$studentResult = $studentStmt->get_result();
$student = $studentResult->fetch_assoc();
$studentStmt->close();

// Fetch the file path for the student's from application slips
$slipQuery = "SELECT file_path FROM add_drop_application_slips WHERE student_id = '$studentId'";
$slipResult = $con->query($slipQuery);
$slip = $slipResult->fetch_assoc();

// Fetch add/drop application details
$applicationQuery = "SELECT subject_name, subject_code, credit_hours, subject_section, action, status 
                     FROM add_drop_application 
                     WHERE student_id = '$studentId' AND status = 'approved'";
$applicationResult = $con->query($applicationQuery);

// Fetch subjects data for dropdown
$subjectsQuery = "SELECT subject_code, subject_name, credit_hours FROM subjects";
$subjectsResult = $con->query($subjectsQuery);
$subjects = [];
while ($subject = $subjectsResult->fetch_assoc()) {
    $subjects[] = $subject;
}

// Handle form submission to update student subjects
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updatedSubjects = $_POST['subjects'] ?? [];

    foreach ($updatedSubjects as $subject) {
        // Check required fields
        $subjectCode = $subject['subject_code'] ?? '';
        $subjectName = $subject['subject_name'] ?? '';
        $creditHours = $subject['credit_hours'] ?? '';

        if (empty($subjectCode) || empty($subjectName) || empty($creditHours)) {
            continue; // Skip incomplete entries
        }

        $section = $subject['section'] ?? null;

        // Insert or update the updated subjects in student_updated_subjects
        $updateQuery = "INSERT INTO student_updated_subjects (student_id, subject_code, subject_name, credit_hours, section) 
                        VALUES ('$studentId', '$subjectCode', '$subjectName', '$creditHours', '$section')
                        ON DUPLICATE KEY UPDATE 
                        subject_name = VALUES(subject_name), credit_hours = VALUES(credit_hours), section = VALUES(section)";
        $con->query($updateQuery);
    }

    header("Location: admin-approvestud.php?student_id=$studentId&success=1");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FCOM ADMS - Student Application Approval</title>
    <style>
        /* Style adjustments */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Roboto', sans-serif; }
        body { background-color: #f1f5f9; display: flex; flex-direction: column; align-items: center; color: #333; padding: 20px; }
        .header { width: 100%; background-color: #0d47a1; color: white; padding: 15px 20px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); border-radius: 8px; }
        .header h1 { font-size: 26px; font-weight: bold; margin: 0; }
        .header-nav a { color: white; text-decoration: none; font-size: 16px; font-weight: bold; margin-left: 20px; }
        .header-nav a:hover { text-decoration: underline; }
        .student-details, .table-section { background-color: #F1F1F1; padding: 20px; margin: 20px; border-radius: 8px; width: 80%; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; background-color: white; border-radius: 8px; overflow: hidden; margin-top: 20px; }
        table th, table td { padding: 15px; text-align: center; font-size: 16px; }
        th { background-color: #0d47a1; color: white; font-weight: bold; }
        tr:hover { background-color: #f1f5f9; }
        .submit-button { background-color: #28A745; color: white; border: none; border-radius: 12px; padding: 0.5rem 1.5rem; font-weight: bold; cursor: pointer; margin-top: 20px; }
        .submit-button:hover { background-color: #218838; }
        .subject-select, .credit-hours-select, .section-input { width: 100%; padding: 8px; border-radius: 8px; }
    </style>
    <script>
        function populateSubjectDetails(row, subjects) {
            const subjectCode = row.querySelector(".subject-code");
            const subjectName = row.querySelector(".subject-name");
            const creditHours = row.querySelector(".credit-hours-select");

            const selected = subjects.find(s => s.subject_code === subjectCode.value);
            if (selected) {
                subjectName.value = selected.subject_name;
                creditHours.value = selected.credit_hours;
            } else {
                subjectName.value = "";
                creditHours.value = "";
            }
        }
    </script>
</head>
<body>
<div class="header">
    <h1>FCOM ADD DROP MANAGEMENT SYSTEM</h1>
    <div class="header-nav">
        <a href="openMS.php">Back</a>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
    <div style="background-color: #dff0d8; color: #3c763d; padding: 15px; border-radius: 5px; text-align: center; width: 80%; margin: 20px;">
        Changes submitted successfully!
    </div>
<?php endif; ?>

<div class="student-details">
    <p><strong>STUDENT DETAILS</strong></p>
    <?php if ($student): ?>
            <p><strong>Full Name:</strong> <?php echo htmlspecialchars($student['student_name']); ?></p>
            <p><strong>IC No:</strong> <?php echo htmlspecialchars($student['ic_no']); ?></p>
            <p><strong>Student ID:</strong> <?php echo htmlspecialchars($student['student_id']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></p>
            <p><strong>Semester:</strong> <?php echo htmlspecialchars($student['semester']); ?></p>
            <p><strong>Session:</strong> <?php echo htmlspecialchars($student['session']); ?></p>
            <p><strong>Active:</strong> <?php echo $student['active'] === 'Y' ? 'Yes' : 'No'; ?></p>
    <?php else: ?>
        <p>No student details found.</p>
    <?php endif; ?>
</div>

<div class="table-section">
    <h2>Add Drop Subject Application Slip</h2>
    <?php if ($slip && !empty($slip['file_path'])): ?>
        <p><a href="<?php echo htmlspecialchars($slip['file_path']); ?>" target="_blank">View Subject Application Slip</a></p>
    <?php else: ?>
        <p>No subject slip found for this student.</p>
    <?php endif; ?>
</div>


<div class="table-section">
    <h2>Add/Drop Application Details</h2>
    <table>
        <thead>
            <tr>
                <th>Subject Code</th>
                <th>Subject Name</th>
                <th>Credit Hours</th>
                <th>Section</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($applicationResult->num_rows > 0): ?>
                <?php while ($row = $applicationResult->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['subject_code']); ?></td>
                        <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['credit_hours']); ?></td>
                        <td><?php echo htmlspecialchars($row['subject_section']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No approved applications found for this student.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<form method="POST">
    <div class="table-section">
        <h2>Update Student Subjects</h2>
        <table>
            <thead>
                <tr>
                    <th>Subject Code</th>
                    <th>Subject Name</th>
                    <th>Credit Hours</th>
                    <th>Section</th>
                </tr>
            </thead>
            <tbody>
                <?php for ($i = 0; $i < 6; $i++): ?>
                    <tr>
                        <td>
                            <select name="subjects[<?php echo $i; ?>][subject_code]" class="subject-code subject-select" onchange="populateSubjectDetails(this.parentElement.parentElement, <?php echo htmlspecialchars(json_encode($subjects)); ?>)">
                                <option value="">Select Subject</option>
                                <?php foreach ($subjects as $subject): ?>
                                    <option value="<?php echo $subject['subject_code']; ?>"><?php echo $subject['subject_code']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td><input type="text" name="subjects[<?php echo $i; ?>][subject_name]" class="subject-name" readonly></td>
                        <td>
                            <select name="subjects[<?php echo $i; ?>][credit_hours]" class="credit-hours-select">
                                <option value="">Select Credit Hours</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </td>
                        <td><input type="text" name="subjects[<?php echo $i; ?>][section]" class="section-input"></td>
                    </tr>
                <?php endfor; ?>
            </tbody>
        </table>
        <button type="submit" class="submit-button">Submit Changes</button>
    </div>
</form>
</body>
</html>
