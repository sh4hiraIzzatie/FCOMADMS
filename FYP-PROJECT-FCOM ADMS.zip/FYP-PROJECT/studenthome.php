<?php
session_start();
include("database.php");  // Include your database connection

// Get the student ID from the session
$student_id = $_SESSION['student_id'];  // assuming student ID is stored in session

// Fetch updated subjects from the database
$subjectsQuery = "SELECT subject_code, subject_name, credit_hours, section FROM student_updated_subjects WHERE student_id = ?";
$stmt = $con->prepare($subjectsQuery);
$stmt->bind_param('s', $student_id);
$stmt->execute();
$result = $stmt->get_result();
$updatedSubjects = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Home</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f9fb;
            margin: 0;
            padding: 0;
        }
        
        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .logo1{
            width: 80px;
            height: 45px;
            margin: 0 5px;
        }

        .logo2{
            width: 100px;
            height: 60px;
            margin: 0 5px;
        }

        /* Left-side navigation */
        .navbar {
            width: 220px;
            background-color: #0b0e33;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding: 20px;
            border-radius: 0 15px 15px 0;
            box-shadow: 2px 0 8px rgba(0,0,0,0.3);
        }

        .navbar a {
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #34495e;
        }

        h3 {
            font-size: 18px;
            color: #3893e8;
        }
        /* Main Content */
        .container {
            margin-left: 250px;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 12px;
            margin-top: 20px;
        }

        h1 {
            font-size: 28px;
            color: #333;
            margin-top: 0;
        }

        .welcome-message {
            background-color: #e0f7fa;
            border-left: 5px solid #009688;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table h2 {
            text-align: center;
            color: #2c3e50;
        }

        table th, table td {
            padding: 15px;
            text-align: center;
            font-size: 16px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #0b0e33;
            color: white;
            font-weight: bold;
        }
        tr:hover {
            background-color: #f1f1f1;
        }

        /* Subject Tracking Styling */
        .subject-tracking {
            margin-top: 40px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: #f4f6f9;
        }

        .subject-tracking h2 {
            text-align: center;
            color: #2c3e50;
        }

        .semester {
            margin-bottom: 20px;
        }

        .semester h3 {
            font-size: 20px;
            color: #3893e8;
            margin-bottom: 10px;
        }

        .subjects {
            padding-left: 20px;
        }

    </style>
</head>
<body>

<div class="navbar">
    <!-- Logos displayed side by side -->
    <div class="logo-container">
        <img class="logo1" src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img class="logo2" src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
    
    <!-- Navigation links -->
    <h2>FCOM ADMS</h2>
    <h3>ACADEMIC</h3>
    <a href="studenthome.php">Info</a>
    <a href="student-appslip.php">Application Slip</a>
    <a href="student-adddrop.php">Add/Drop</a>
    <h3>PROFILE</h3>
    <a href="studentprofile.php">Personal Information</a>
    <a href="faq-student.php">FAQ</a>
    <a href="student-login.php">Logout</a>
</div>

<div class="container">
    <div class="welcome-message">
        <p>Welcome, <?php echo $_SESSION['student_id']; ?>! You are now logged in.</p>
    </div>

    <div>
        <h2>New Subject Slip</h2>
        <?php if (!empty($updatedSubjects)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Subject Code</th>
                        <th>Subject Name</th>
                        <th>Credit Hours</th>
                        <th>Section</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($updatedSubjects as $subject): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($subject['subject_code']); ?></td>
                            <td><?php echo htmlspecialchars($subject['subject_name']); ?></td>
                            <td><?php echo htmlspecialchars($subject['credit_hours']); ?></td>
                            <td><?php echo htmlspecialchars($subject['section']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Your application is still under review.</p>
        <?php endif; ?>
    </div>

    <div class="subject-tracking">
        <h2>Subject Structure by Semester</h2>
        
        <div class="semester">
            <h3>Semester 1/Year 1</h3>
            <ul class="subjects">
                <li>Computer Organisation and Architecture</li>
                <li>Operating Systems</li>
                <li>Digital Technology and Society</li>
                <li>Discrete Mathematics 1</li>
                <li>Introduction to Object-Oriented Programming</li>
                <li>Penghayatan Etika dan Peradaban</li>
            </ul>
        </div>
        
        <div class="semester">
            <h3>Semester 2/Year 1</h3>
            <ul class="subjects">
                <li>Database Fundamentals</li>
                <li>Human Computer Interaction</li>
                <li>Computer Systems and Networking (Cisco 1)</li>
                <li>Data Structure and Algorithm</li>
                <li>Advanced Object-Oriented Programming</li>
                <li>Falsafah dan Isu Semasa</li>
            </ul>
        </div>

        <div class="semester">
            <h3>Semester 3/Year 1</h3>
            <ul class="subjects">
                <li>Discrete Mathematics 2</li>
                <li>Leadership and Interpersonal Skill</li>
                <li>Arabic 1/ Mandarin 1/ French 1</li>
            </ul>
        </div>
        
        <div class="semester">
            <h3>Semester 4/Year 2</h3>
            <ul class="subjects">
                <li>Database Management and Information Retrieval</li>
                <li>Object Oriented System Analysis and Design</li>
                <li>Web Application Development</li>
                <li>Mobile Applications Development</li>
                <li>Arabic 2/ Mandarin 2/ French 2</li>
            </ul>
        </div>

        <div class="semester">
            <h3>Semester 5/Year 2</h3>
            <ul class="subjects">
                <li>Information System Security</li>
                <li>Software Project Management</li>
                <li>User Interface Development</li>
                <li>Enterprise Application Development</li>
                <li>Academic Writing</li>
            </ul>
        </div>

        <div class="semester">
            <h3>Semester 6/Year 2</h3>
            <ul class="subjects">
                <li>Pengajian Islam 3 / Ethics and Moral 3</li>
                <li>Bahasa Kebangsaan A</li>
                <li>Khidmat Masyarakat 2</li>
                <li>Personal Development/ Creativity and Innovation</li>
            </ul>
        </div>

        <div class="semester">
            <h3>Semester 7/Year 3</h3>
            <ul class="subjects">
                <li>Computing Project 1</li>
                <li>Introduction to Data Analytics</li>
                <li>Advanced Application Development</li>
                <li>Software Testing and Quality Assurance</li>
                <li>Effective Communication</li>
            </ul>
        </div>

        <div class="semester">
            <h3>Semester 8/Year 3</h3>
            <ul class="subjects">
                <li>Computing Project 2</li>
                <li>Business Information Management Strategy</li>
                <li>Integrated Marketing Communications</li>
                <li>Entrepreneurship with Digital Application 2</li>
            </ul>
        </div>

        <div class="semester">
            <h3>Semester 9/Year 3</h3>
            <ul class="subjects">
                <li>Industrial Training</li>
            </ul>
        </div>
    </div>
</div>

<script>
    // Display login success message if login parameter is in the URL
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('login')) {
        alert("Login successful!");
    }
</script>

</body>
</html>
