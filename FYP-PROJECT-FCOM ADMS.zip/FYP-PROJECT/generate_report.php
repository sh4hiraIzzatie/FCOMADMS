<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    // Fetch data sorted by status
    $query = "SELECT * FROM add_drop_application ORDER BY status";
    $result = $con->query($query);

    $applications = [];
    while ($row = $result->fetch_assoc()) {
        $applications[] = $row;
    }

    if ($action === 'print') {
        // Generate printable HTML report
        echo "<h1>Student Application Report</h1>";
        echo "<table border='1' cellpadding='10'>";
        echo "<tr><th>Application ID</th><th>Student ID</th><th>Status</th></tr>";
        foreach ($applications as $app) {
            echo "<tr>";
            echo "<td>{$app['application_id']}</td>";
            echo "<td>{$app['student_id']}</td>";
            echo "<td>{$app['status']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } elseif ($action === 'download') {
        // Generate CSV
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="student_applications.csv"');

        $output = fopen('php://output', 'w');
        fputcsv($output, ['Application ID', 'Student ID', 'Status']);

        foreach ($applications as $app) {
            fputcsv($output, [$app['application_id'], $app['student_id'], $app['status']]);
        }
        fclose($output);
    }
}

$con->close();
?>
