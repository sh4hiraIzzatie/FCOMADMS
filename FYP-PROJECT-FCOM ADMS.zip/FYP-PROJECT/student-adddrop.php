<?php
session_start();
include("database.php");  // Include your database connection

$student_id = $_SESSION['student_id'];  // Get student ID from session

// Check if an existing add/drop application is pending, approved, or rejected
$existing_application_query = "
    SELECT status, reject_reason 
    FROM add_drop_application 
    WHERE student_id = '$student_id' 
    AND status IN ('pending', 'approved', 'rejected')";
$existing_application_result = $con->query($existing_application_query);

$can_submit = true;  // Default to allow submission if no condition blocks it
$rejection_message = null;
$approved_message = null;

if ($existing_application_result->num_rows > 0) {
    while ($row = $existing_application_result->fetch_assoc()) {
        if ($row['status'] === 'pending') {
            $can_submit = false;  // Submission is not allowed if there's a pending application
        } elseif ($row['status'] === 'approved') {
            $approved_message = "Your application has been approved!";
            $can_submit = false;
        } elseif ($row['status'] === 'rejected') {
            $rejection_message = $row['reject_reason'];  // Fetch the rejection reason if application was rejected
        }
    }
}

// Fetch all available subjects
$query = "SELECT subject_name, subject_code FROM subjects";
$result_subjects = $con->query($query);
$subjects = [];
while ($row = $result_subjects->fetch_assoc()) {
    $subjects[] = $row;
}

// Handle form submission for add/drop subjects
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $can_submit) {
    $subjects_to_add = $_POST['subjects_to_add'] ?? [];
    $subjects_to_drop = $_POST['subjects_to_drop'] ?? [];
    $signature = $_POST['signatureData'] ?? '';  // Capture the drawn signature data

    if (!empty($signature)) {
        foreach ($subjects_to_add as $key => $subject_code) {
            if (!empty($subject_code)) {
                $subject_name = $_POST['subject_name_add'][$key];
                $credit_hours = $_POST['credit_hours_add'][$key];
                $subject_section = $_POST['subject_section_add'][$key];

                $query = "INSERT INTO add_drop_application (student_id, subject_code, subject_name, credit_hours, subject_section, action, status, signature) 
                          VALUES ('$student_id', '$subject_code', '$subject_name', '$credit_hours', '$subject_section', 'add', 'pending', '$signature')";
                $con->query($query);
            }
        }
        foreach ($subjects_to_drop as $key => $subject_code) {
            if (!empty($subject_code)) {
                $subject_name = $_POST['subject_name_drop'][$key];
                $credit_hours = $_POST['credit_hours_drop'][$key];
                $subject_section = $_POST['subject_section_drop'][$key];

                $query = "INSERT INTO add_drop_application (student_id, subject_code, subject_name, credit_hours, subject_section, action, status, signature) 
                          VALUES ('$student_id', '$subject_code', '$subject_name', '$credit_hours', '$subject_section', 'drop', 'pending', '$signature')";
                $con->query($query);
            }
        }
        $_SESSION['application_submitted'] = true;  // Mark application as submitted in session
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    } else {
        $error_message = "Please provide a digital signature before submitting.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Add/Drop Subjects</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f9fb;
            margin: 0;
            padding: 0;
        }
        
        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .logo1{
            width: 80px;
            height: 45px;
            margin: 0 5px;
        }

        .logo2{
            width: 100px;
            height: 60px;
            margin: 0 5px;
        }

        /* Left-side navigation */
        .navbar {
            width: 220px;
            background-color: #0b0e33;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding: 20px;
            border-radius: 0 15px 15px 0;
            box-shadow: 2px 0 8px rgba(0,0,0,0.3);
        }

        .navbar a {
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #34495e;
        }

        h3 {
            font-size: 18px;
            color: #3893e8;
        }

        .notification {
            background-color: #dff0d8;
            color: #3c763d;
            padding: 15px;
            margin: 20px;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .notification.error {
            background-color: #f8d7da;
            color: #721c24;
        }

        .container {
            margin-left: 250px;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 12px;
            margin-top: 20px;
        }

        .container h1 {
            font-size: 26px;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
        }

        .selection-group {
            margin-bottom: 30px;
        }

        .selection-box {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f1f5f9;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.1);
            margin-bottom: 10px;
        }

        select, input[type="text"] {
            padding: 8px;
            font-size: 14px;
            width: 150px;
            border-radius: 5px;
            border: 1px solid #ced4da;
        }

        .label {
            font-weight: bold;
            color: #333;
            width: 100px;
            text-align: left;
        }

        .submit-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            display: block;
            margin: 0 auto;
            margin-top: 20px;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        .popup-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.6); justify-content: center; align-items: center; }

        .signature-box { width: 400px; background-color: #fff; border-radius: 10px; padding: 20px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3); text-align: center; }
        .signature-box h3 { color: #333; margin-bottom: 10px; }
        .signature-box button { padding: 10px 20px; background-color: #007bff; color: #fff; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; margin-top: 15px; }
        .signature-box button:hover { background-color: #0056b3; }
        #signatureCanvas { border: 1px solid #ccc; border-radius: 5px; width: 100%; height: 200px; cursor: crosshair; }
    </style>
    <script>
        function toggleSubmitButton() {
            var declarationCheckbox = document.getElementById("declaration");
            var submitButton = document.getElementById("submitButton");
            submitButton.disabled = !declarationCheckbox.checked;
        }

        function showSignaturePopup() {
            document.getElementById("signaturePopup").style.display = "flex";
        }

        function clearCanvas() {
            const canvas = document.getElementById('signatureCanvas');
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }

        function closeSignaturePopup(confirm) {
            if (confirm) {
                const canvas = document.getElementById('signatureCanvas');
                const signatureData = canvas.toDataURL('image/png');
                document.getElementById('signatureData').value = signatureData;
                if (signatureData === '') {
                    alert("Please provide a digital signature.");
                    return;
                }
                document.getElementById("subjectForm").submit();
            }
            document.getElementById("signaturePopup").style.display = "none";
        }

        function printApplication() {
            const printContents = document.getElementById('printableApplication').innerHTML;
            const originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
    </script>
</head>
<body>
<div class="navbar">
    <!-- Logos displayed side by side -->
    <div class="logo-container">
        <img class="logo1" src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img class="logo2" src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
    
    <!-- Navigation links -->
    <h2>FCOM ADMS</h2>
    <h3>ACADEMIC</h3>
    <a href="studenthome.php">Info</a>
    <a href="student-appslip.php">Application Slip</a>
    <a href="student-adddrop.php">Add/Drop</a>
    <h3>PROFILE</h3>
    <a href="studentprofile.php">Personal Information</a>
    <a href="faq-student.php">FAQ</a>
    <a href="student-login.php">Logout</a>
</div>

<div class="container">
    <!-- Print Application Button -->
    <label for="declaration">After you have submitted this application, please download your application slip and upload it on the subject slip page.</label>
    <button class="print-btn" onclick="printApplication()">Print & Download Application</button>
    <h1>ADD/DROP APPLICATION</h1>
    
    <?php if (isset($error_message)): ?>
        <div class="notification error"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <?php if (!$can_submit && $approved_message): ?>
        <div class="notification"><?php echo $approved_message; ?></div>
    <?php elseif (!$can_submit): ?>
        <div class="notification error">Your application has already been submitted and is pending review.</div>
    <?php elseif (isset($_SESSION['application_submitted'])): ?>
        <div class="notification">Your application has been submitted. We will notify you later.</div>
        <?php unset($_SESSION['application_submitted']); ?>
    <?php endif; ?>

    <?php if ($rejection_message): ?>
        <div class="notification error">Your application was rejected. Reason: <?php echo htmlspecialchars($rejection_message); ?></div>
    <?php endif; ?>
    
    <form id="subjectForm" method="post" action="">
    
    <form id="subjectForm" method="post" action="">
        <div class="selection-group">
            <h2>Subjects to Add</h2>
            <?php for ($i = 0; $i < 6; $i++): ?>
                <div class="selection-box">
                    <label class="label">Subject <?php echo $i + 1; ?></label>
                    <select name="subjects_to_add[]">
                        <option value="">Select Subject Code</option>
                        <?php foreach ($subjects as $subject): ?>
                            <option value="<?php echo $subject['subject_code']; ?>"><?php echo $subject['subject_code']; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="subject_name_add[]">
                        <option value="">Select Subject Name</option>
                        <?php foreach ($subjects as $subject): ?>
                            <option value="<?php echo $subject['subject_name']; ?>"><?php echo $subject['subject_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="credit_hours_add[]">
                        <option value="">Credit Hours</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                    <input type="text" name="subject_section_add[]" placeholder="Section">
                </div>
            <?php endfor; ?>
        </div>

        <div class="selection-group">
            <h2>Subjects to Drop</h2>
            <?php for ($i = 0; $i < 6; $i++): ?>
                <div class="selection-box">
                    <label class="label">Subject <?php echo $i + 1; ?></label>
                    <select name="subjects_to_drop[]">
                        <option value="">Select Subject Code</option>
                        <?php foreach ($subjects as $subject): ?>
                            <option value="<?php echo $subject['subject_code']; ?>"><?php echo $subject['subject_code']; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="subject_name_drop[]">
                        <option value="">Select Subject Name</option>
                        <?php foreach ($subjects as $subject): ?>
                            <option value="<?php echo $subject['subject_name']; ?>"><?php echo $subject['subject_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="credit_hours_drop[]">
                        <option value="">Credit Hours</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                    <input type="text" name="subject_section_drop[]" placeholder="Section">
                </div>
            <?php endfor; ?>
        </div>

        <div style="margin-top: 20px; text-align: center;">
            <input type="checkbox" id="declaration" onclick="toggleSubmitButton()">
            <label for="declaration">I would like to add/drop courses mentioned above. Failure to register may affect my program enrollment and examination.</label>
        </div>

        <input type="hidden" id="signatureData" name="signatureData">
        <button type="button" class="submit-btn" id="submitButton" onclick="showSignaturePopup()" disabled>Submit</button>
    </form>

    <!-- Printable Application Section -->
    <div id="printableApplication" style="display: none;">
        <h2>Application Details</h2>
        <p><strong>Student ID:</strong> <?php echo htmlspecialchars($student_id); ?></p>
        <h2>Subject Applications</h2>
        <table>
            <thead>
                <tr>
                    <th>Subject Code</th>
                    <th>Subject Name</th>
                    <th>Credit Hours</th>
                    <th>Section</th>
                    <th>Action</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $application_query = "
                    SELECT subject_code, subject_name, credit_hours, subject_section, action, status, reject_reason
                    FROM add_drop_application
                    WHERE student_id = '$student_id'";
                $application_result = $con->query($application_query);
                while ($row = $application_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['subject_code']); ?></td>
                        <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['credit_hours']); ?></td>
                        <td><?php echo htmlspecialchars($row['subject_section']); ?></td>
                        <td><?php echo htmlspecialchars($row['action']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="popup-overlay" id="signaturePopup">
    <div class="signature-box">
        <h3>Provide Your Digital Signature</h3>
        <canvas id="signatureCanvas" width="400" height="200" style="border: 1px solid #ccc; border-radius: 5px;"></canvas>
        <div>
            <button onclick="clearCanvas()">Clear</button>
            <button onclick="closeSignaturePopup(true)">Confirm</button>
            <button onclick="closeSignaturePopup(false)">Cancel</button>
        </div>
    </div>
</div>

<script>
    let isDrawing = false;
    let ctx = null;

    function setupCanvas() {
        const canvas = document.getElementById('signatureCanvas');
        ctx = canvas.getContext('2d');

        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.strokeStyle = '#000';

        canvas.addEventListener('mousedown', startDrawing);
        canvas.addEventListener('mousemove', draw);
        canvas.addEventListener('mouseup', stopDrawing);
        canvas.addEventListener('mouseleave', stopDrawing);

        canvas.addEventListener('touchstart', (e) => {
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousedown', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            canvas.dispatchEvent(mouseEvent);
        });

        canvas.addEventListener('touchmove', (e) => {
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousemove', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            canvas.dispatchEvent(mouseEvent);
        });

        canvas.addEventListener('touchend', (e) => {
            const mouseEvent = new MouseEvent('mouseup', {});
            canvas.dispatchEvent(mouseEvent);
        });
    }

    function startDrawing(event) {
        isDrawing = true;
        ctx.beginPath();
        ctx.moveTo(event.offsetX, event.offsetY);
    }

    function draw(event) {
        if (!isDrawing) return;
        ctx.lineTo(event.offsetX, event.offsetY);
        ctx.stroke();
    }

    function stopDrawing() {
        isDrawing = false;
        ctx.closePath();
    }

    function clearCanvas() {
        const canvas = document.getElementById('signatureCanvas');
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    }

    function closeSignaturePopup(confirm) {
        if (confirm) {
            const canvas = document.getElementById('signatureCanvas');
            const signatureData = canvas.toDataURL('image/png');
            document.getElementById('signatureData').value = signatureData;

            if (signatureData === '') {
                alert("Please provide a digital signature.");
                return;
            }
            document.getElementById("subjectForm").submit();
        }
        document.getElementById("signaturePopup").style.display = "none";
    }

    window.onload = setupCanvas;
</script>

</body>
</html>