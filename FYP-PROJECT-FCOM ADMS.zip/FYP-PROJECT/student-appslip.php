<?php
session_start();
include("database.php");

// Fetch student ID from session
$student_id = $_SESSION['student_id'];

// Handle file upload for subject slip
if (isset($_FILES['application_slip'])) {
    $file = $_FILES['application_slip'];
    if ($file['type'] == 'application/pdf') {
        $file_name = "{$student_id}_application_slip.pdf"; // Unique file name using student ID
        $file_tmp = $file['tmp_name'];
        $file_path = "uploads/$file_name"; // File path based on student ID

        // Check if 'uploads' directory exists
        if (!is_dir("uploads")) {
            mkdir("uploads", 0777, true); // Create 'uploads' directory if it doesn't exist
        }

        // Move the file to the uploads directory
        if (move_uploaded_file($file_tmp, $file_path)) {
            // Insert or update the file path in the database for the current student
            $insert_file_sql = "INSERT INTO add_drop_application_slips (student_id, file_path) VALUES ('$student_id', '$file_path')
                                ON DUPLICATE KEY UPDATE file_path='$file_path'";
            mysqli_query($con, $insert_file_sql);
            echo "<script>alert('File uploaded successfully!');</script>";
        } else {
            echo "<script>alert('Failed to upload file.');</script>";
        }
    } else {
        echo "<script>alert('Please upload a valid PDF file.');</script>";
    }
}

// Fetch subject slip file path if uploaded for this specific student
$fetch_file_sql = "SELECT file_path FROM add_drop_application_slips WHERE student_id = '$student_id' LIMIT 1";
$file_result = mysqli_query($con, $fetch_file_sql);
$file_row = mysqli_fetch_assoc($file_result);
$uploaded_file_path = $file_row['file_path'] ?? null;

// Fetch status of add/drop application
$application_status_sql = "SELECT status FROM add_drop_application WHERE student_id = '$student_id' ORDER BY application_date DESC LIMIT 1";
$application_status_result = mysqli_query($con, $application_status_sql);
$application_status_row = mysqli_fetch_assoc($application_status_result);
$application_status = $application_status_row['status'] ?? 'No applications submitted.';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Existing Student Subject</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f9fb;
            margin: 0;
            padding: 0;
        }
        
        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .logo1{
            width: 80px;
            height: 45px;
            margin: 0 5px;
        }

        .logo2{
            width: 100px;
            height: 60px;
            margin: 0 5px;
        }

        /* Left-side navigation */
        .navbar {
            width: 220px;
            background-color: #0b0e33;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding: 20px;
            border-radius: 0 15px 15px 0;
            box-shadow: 2px 0 8px rgba(0,0,0,0.3);
        }

        .navbar a {
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #34495e;
        }

        h3 {
            font-size: 18px;
            color: #3893e8;
        }

        .container {
            margin-left: 250px;
            padding: 30px;
            background-color: #fff;
            min-height: 100vh;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 12px;
            margin-top: 20px;
        }

        h1 {
            font-size: 26px;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
        }

        .pdf-viewer {
            display: flex;
            justify-content: center;
            margin: 20px auto;
            width: 90%;
            height: 600px;
            border: 1px solid #ddd;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .pdf-viewer iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        .notification {
            background-color: #dff0d8;
            color: #3c763d;
            padding: 15px;
            margin: 20px;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .notification.error {
            background-color: #f8d7da;
            color: #721c24;
        }

        .function-box {
            margin: 20px;
            padding: 20px 40px;
            border: 2px solid #007bff;
            background-color: #fff;
            cursor: pointer;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            font-size: 16px;
            color: #007bff;
            font-weight: bold;
            transition: background-color 0.3s, color 0.3s;
        }

        .function-box:hover {
            background-color: #00ff59;
            color: #fff;
        }

        .popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 999;
        }

        .popup-content {
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            width: 450px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            animation: popupShow 0.3s ease-out;
        }

        .popup-content h3 {
            font-size: 22px;
            margin-bottom: 20px;
            color: #007bff;
            text-align: center;
            font-weight: bold;
        }

        .popup-content form {
            display: flex;
            flex-direction: column;
        }

        .popup-content input[type="file"],
        .popup-content button {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 16px;
        }

        .popup-content button {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
            border: none;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }

        .popup-content button:hover {
            background-color: #0056b3;
        }

        .close {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 20px;
            color: #333;
            cursor: pointer;
        }

        @keyframes popupShow {
            from {
                transform: scale(0.8);
                opacity: 0;
            }
            to {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>
</head>
<body>

<div class="navbar">
    <!-- Logos displayed side by side -->
    <div class="logo-container">
        <img class="logo1" src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img class="logo2" src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
    
    <!-- Navigation links -->
    <h2>FCOM ADMS</h2>
    <h3>ACADEMIC</h3>
    <a href="studenthome.php">Info</a>
    <a href="student-appslip.php">Application Slip</a>
    <a href="student-adddrop.php">Add/Drop</a>
    <h3>PROFILE</h3>
    <a href="studentprofile.php">Personal Information</a>
    <a href="faq-student.php">FAQ</a>
    <a href="student-login.php">Logout</a>
</div>

<div class="container">
    <h1>ADD DROP APPLICATION SLIP</h1>

    <!-- PDF Viewer if uploaded -->
    <?php if ($uploaded_file_path): ?>
        <div class="pdf-viewer">
            <iframe src="<?= htmlspecialchars($uploaded_file_path); ?>" frameborder="0"></iframe>
        </div>
    <?php else: ?>
        <p style="text-align: center; color: red;">No  slip uploaded yet.</p>
    <?php endif; ?>

    <!-- Display Add/Drop Application Status Below Subject Slip -->
    <div class="notification">
        <strong>Application Status:</strong> <?= htmlspecialchars($application_status); ?>
    </div>

    <div class="function-box" id="uploadSlipBtn">Upload Application Slip</div>
</div>

<!-- Popup for PDF Upload -->
<div id="uploadSlipPopup" class="popup">
    <div class="popup-content">
        <span class="close">&times;</span>
        <h3>The subject slip should be originally / downloaded from add drop page</h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="application_slip" required>
            <button type="submit">Upload</button>
        </form>
    </div>
</div>

<script>
    const uploadBtn = document.getElementById('uploadSlipBtn');
    const closeBtns = document.querySelectorAll('.close');

    uploadBtn.addEventListener('click', () => {
        document.getElementById('uploadSlipPopup').style.display = 'flex';
    });

    closeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            btn.closest('.popup').style.display = 'none';
        });
    });

    window.addEventListener('click', function(e) {
        const uploadPopup = document.getElementById('uploadSlipPopup');
        if (e.target === uploadPopup) {
            uploadPopup.style.display = 'none';
        }
    });
</script>

</body>
</html>

