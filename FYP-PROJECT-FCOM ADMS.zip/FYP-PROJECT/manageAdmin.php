<?php
session_start();
include 'database.php';

// Create Admin
if (isset($_POST['create_admin'])) {
    $admin_id = $_POST['admin_id'];
    $admin_name = $_POST['admin_name'];
    $admin_email = $_POST['admin_email'];
    $admin_password = password_hash($_POST['admin_password'], PASSWORD_DEFAULT);

    // Check if the admin_id already exists
    $check_sql = "SELECT * FROM managea WHERE admin_id = '$admin_id'";
    $check_result = mysqli_query($con, $check_sql);
    if (mysqli_num_rows($check_result) > 0) {
        header("Location: manageAdmin.php?message=Admin ID already exists&type=error");
        exit();
    }

    // Insert new admin
    $sql = "INSERT INTO managea (admin_id, admin_name, admin_email, admin_password) 
            VALUES ('$admin_id', '$admin_name', '$admin_email', '$admin_password')";
    if (mysqli_query($con, $sql)) {
        header("Location: manageAdmin.php?message=Admin created successfully&type=success");
    } else {
        header("Location: manageAdmin.php?message=Error creating admin&type=error");
    }
    exit();
}

// Delete Admin
if (isset($_GET['delete_admin'])) {
    $admin_id = $_GET['delete_admin'];
    $sql = "DELETE FROM managea WHERE admin_id = '$admin_id'";
    if (mysqli_query($con, $sql)) {
        header("Location: manageAdmin.php?message=Admin deleted successfully&type=success");
    } else {
        header("Location: manageAdmin.php?message=Error deleting admin&type=error");
    }
    exit();
}

// Search Admin
$search_query = '';
if (isset($_GET['search_query'])) {
    $search_query = $_GET['search_query'];
    $sql = "SELECT * FROM managea WHERE admin_id LIKE '%$search_query%' OR 
                                      admin_name LIKE '%$search_query%' OR 
                                      admin_email LIKE '%$search_query%'";
} else {
    // Fetch all admins from the database
    $sql = "SELECT * FROM managea";
}

$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body 
        {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        nav ul 
        {
            background-color: #4c8bf5;
            padding: 15px;
            list-style-type: none;
            margin: 0;
            text-align: center;
        }

        nav ul li 
        {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a 
        {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .admin-section 
        {
            width: 80%;
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .admin-section h2 {
            text-align: center;
            font-size: 1.5rem;
            margin-bottom: 20px;
        }

        form 
        {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        form label 
        {
            width: 100%;
            margin-bottom: 8px;
            text-align: left;
        }

        input[type="text"],
        input[type="password"],
        input[type="email"],
        input[type="search"] {
            width: 90%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #4c8bf5;
            color: white;
           border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            width: 90%;
        }

        input[type="submit"]:hover 
        {
            background-color: #3b6fbc;
        }

        .table-container 
        {
            width: 80%;
            max-width: 900px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table 
        {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }

        table th,
        table td 
        {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }

        .delete-btn 
        {
            background-color: #ff5c5c;
            color: white;
            padding: 8px 16px;
            padding: 8px 16px;
            padding: 8px 16px;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            padding: 8px 16px;
            text-decoration: none;
            padding: 8px 16px;
        }

        .delete-btn:hover 
        {
            background-color: #e04b4b;
        }

        /* Footer */
        footer 
        {
            text-align: center;
            padding: 20px;
            background-color: #4c8bf5;
            color: white;
            margin-top: 20px;
        }

        footer p 
        {
            margin: 0;
        }

        /* Notification styles */
        .notification {
            display: none;
            background-color: #4c8bf5;
            color: white;
            padding: 10px;
            text-align: center;
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            width: 300px;
            z-index: 1000;
            border-radius: 5px;
        }

        .notification.show 
        {
            display: block;
        }

        .notification.success 
        {
            background-color: #4caf50;
        }

        .notification.error 
        {
            background-color: #f44336;
        }

        .close-btn 
        {
            float: right;
            cursor: pointer;
        }
    </style>
</head>
<body>
<header>
        <nav>
            <ul>
                <li><a href="admin-home.php">Home</a></li>
                <li><a href="manageAdmin.php">Admin</a></li>
                <li><a href="manageStudent.php">Student</a></li>
                <li><a href="manageSubject.php">Subject Management</a></li>
                <li><a href="admin-login.php">Logout</a></li>
            </ul>
        </nav>
</header>

    <div id="notification" class="notification">
        <span id="notificationMessage"></span>
        <span id="closeNotification" class="close-btn">&times;</span>
    </div>

    <!-- Create Admin Section -->
    <div class="admin-section">
        <h2>Create Admin</h2>
        <form action="manageAdmin.php" method="POST" class="form-section">
            <label for="admin_id">Admin ID:</label>
            <input type="text" name="admin_id" required>
            <label for="admin_name">Admin Name:</label>
            <input type="text" name="admin_name" required>
            <label for="admin_email">Admin Email:</label>
            <input type="email" name="admin_email" required>
            <label for="admin_password">Password:</label>
            <input type="password" name="admin_password" required>
            <input type="submit" name="create_admin" value="Create Admin">
        </form>

        <h2>Search Admin</h2>
        <form action="manageAdmin.php" method="GET" class="form-section">
            <input type="search" name="search_query" placeholder="Search by ID, Name, Email" required>
            <input type="submit" value="Search">
        </form>
    </div>

    <!-- Admins List Section -->
    <div class="table-container">
        <h2>Admins List</h2>
        <table>
            <thead>
                <tr>
                    <th>Admin ID</th>
                    <th>Admin Name</th>
                    <th>Admin Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['admin_id'] . "</td>";
                        echo "<td>" . $row['admin_name'] . "</td>";
                        echo "<td>" . $row['admin_email'] . "</td>";
                        echo "<td><a href='manageAdmin.php?delete_admin=" . $row['admin_id'] . "' class='delete-btn'>Delete</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No admins found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <footer>
        <p>&copy; 2024 FCOM ADMS. All Rights Reserved.</p>
    </footer>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        const notification = document.getElementById("notification");
        const notificationMessage = document.getElementById("notificationMessage");
        const closeNotification = document.getElementById("closeNotification");

        function showNotification(message, type) {
            notificationMessage.innerText = message;
            notification.classList.add(type, "show");

            setTimeout(function () {
                notification.classList.remove("show", "success", "error");
            }, 5000);
        }

        closeNotification.onclick = function () {
            notification.classList.remove("show", "success", "error");
        };

        const urlParams = new URLSearchParams(window.location.search);
        const message = urlParams.get('message');
        const messageType = urlParams.get('type');

        if (message && messageType) {
            showNotification(message, messageType);
        }
    });
    </script>

</body>
</html>
