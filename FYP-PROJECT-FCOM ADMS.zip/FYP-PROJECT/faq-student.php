<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Home</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f9fb;
            margin: 0;
            padding: 0;
        }
        
        /* Styling for logos */
        .logo-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .logo1{
            width: 80px;
            height: 45px;
            margin: 0 5px;
        }

        .logo2{
            width: 100px;
            height: 60px;
            margin: 0 5px;
        }

        /* Left-side navigation */
        .navbar {
            width: 220px;
            background-color: #0b0e33;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding: 20px;
            border-radius: 0 15px 15px 0;
            box-shadow: 2px 0 8px rgba(0,0,0,0.3);
        }

        .navbar a {
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: block;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #34495e;
        }

        h1 {
            font-size: 26px;
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
        }

        h3 {
            font-size: 18px;
            color: #3893e8;
        }

        /* FAQ Container */
        .faq-container {
            max-width: 900px;
            margin: 50px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
        }

        /* FAQ Header */
        .faq-container h1 {
            text-align: center;
            color: #333333;
            font-size: 32px;
            margin-bottom: 30px;
            position: relative;
        }

        .faq-container h1::after {
            content: "";
            width: 80px;
            height: 4px;
            background: linear-gradient(to right, #007bff, #00c6ff);
            display: block;
            margin: 10px auto 0;
            border-radius: 2px;
        }

        /* Individual FAQ Items */
        .faq {
            margin-bottom: 25px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .faq:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .faq h2 {
            font-size: 20px;
            margin-bottom: 10px;
            color: #007bff;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .faq h2:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .faq p {
            margin: 0;
            font-size: 16px;
            color: #555555;
            line-height: 1.6;
        }

        /* Alternating background for FAQs */
        .faq:nth-child(odd) {
            background: #f1f1f1;
        }

        .faq:nth-child(even) {
            background: #ffffff;
        }

        /* Hover effects for FAQ content */
        .faq:hover h2 {
            color: #004085;
        }

        </style>
</head>
<body>

<div class="navbar">
    <!-- Logos displayed side by side -->
    <div class="logo-container">
        <img class="logo1" src="img/UPTM2-logo.png" alt="UPTM Logo">
        <img class="logo2" src="img/FCOM_logo.png" alt="FCOM Logo">
    </div>
    
    <!-- Navigation links -->
    <h2>FCOM ADMS</h2>
    <h3>ACADEMIC</h3>
    <a href="studenthome.php">Info</a>
    <a href="student-appslip.php">Application Slip</a>
    <a href="student-adddrop.php">Add/Drop</a>
    <h3>PROFILE</h3>
    <a href="studentprofile.php">Personal Information</a>
    <a href="faq-student.php">FAQ</a>
    <a href="student-login.php">Logout</a>
</div>

<div class="faq-container">
    <h1>Frequently Asked Questions</h1>

    <div class="faq">
        <h2>1. How to do the add drop subject application?</h2>
        <p>
            Step 1 - Go to the add drop page and make the changes on the subject that you want to add or drop.<br>
            Step 2 - After done with the course selection whether you want it to be added or dropped, make sure that you click the checkbox declaration, upload your signature, and submit the application.<br>
            Step 3 - After the application has been submitted, please make sure you download the application slip on the top of the add drop application page.<br>
            Step 4 - Upload your add drop subject application slip on the application slip page.<br>
            Step 5 - Wait for the application to be approved.
        </p>
    </div>

    <div class="faq">
        <h2>2. How do I know the progress and status of my add drop application?</h2>
        <p>
            To know the status of your application progress, whether it is pending, approved, or rejected, the system will show your progress status on the add drop page and application page. 
            If you are not doing any application, there will be no status regarding the add drop application update.
        </p>
    </div>

    <div class="faq">
        <h2>3. What if my application is rejected, can I re-apply the add drop application again?</h2>
        <p>
            Yes, students can re-apply their add drop application if their add drop application has been rejected. 
            However, for students with inactive status, they cannot do the add drop application until their status changes to active.
        </p>
    </div>

    <div class="faq">
        <h2>4. After the application has been approved, how do I check the updated subject details/slips</h2>
        <p>
            The approved or successfull application will be shown under the info page. The updated subject will be shown under the Updated Subject's table.<br>
            Or if you want to view your updated subject slip, you can just view from UPTM Campus Management System (CMS).
        </p>
    </div>
</div>

</body>
</html>
