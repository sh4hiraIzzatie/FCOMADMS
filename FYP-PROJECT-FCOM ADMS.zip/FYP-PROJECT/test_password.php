<?php
$plain_password = 'YourTestPassword';
$hashed_password = password_hash($plain_password, PASSWORD_DEFAULT);

echo "Plain Password: $plain_password<br>";
echo "Hashed Password: $hashed_password<br>";

if (password_verify($plain_password, $hashed_password)) {
    echo "Password verified successfully!";
} else {
    echo "Password verification failed!";
}
