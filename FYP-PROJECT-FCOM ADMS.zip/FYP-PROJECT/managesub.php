<?php
session_start();
include 'database.php';

$notification = "";

// Handle form submission for creating new subject
if (isset($_POST['create_subject'])) {
    $subject_name = $_POST['subject_name'];
    $subject_code = $_POST['subject_code'];
    $credit_hours = $_POST['credit_hours'];
    $contact_hours = $_POST['contact_hours'];
    $subject_section = $_POST['subject_section'];

    $query = "INSERT INTO subjects (subject_name, subject_code, credit_hours, contact_hours, subject_section) 
              VALUES ('$subject_name', '$subject_code', '$credit_hours', '$contact_hours', '$subject_section')";
    
    if (mysqli_query($con, $query)) {
        $notification = "New subject added successfully!";
    } else {
        $notification = "Error: " . mysqli_error($con);
    }
}

// Fetch existing subjects
$result = mysqli_query($con, "SELECT * FROM subjects");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subjects</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color: #f1f5f9;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #333;
            padding: 20px;
        }

        /* Enhanced Header Styling */
        .header {
            width: 100%;
            background-color: #0d47a1;
            color: white;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .header h1 {
            font-size: 26px;
            font-weight: bold;
            margin: 0;
        }

        .header-nav a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            margin-left: 20px;
        }

        .header-nav a:hover {
            text-decoration: underline;
        }

        .notification {
            background-color: #4CAF50;
            color: white;
            padding: 12px;
            margin: 10px 0;
            text-align: center;
            border-radius: 8px;
        }

        /* Styling the form container */
    .form-container {
        width: 100%;
        max-width: 1000px;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        padding: 20px;
        margin-top: 20px;
    }

    .form-container h2 {
        text-align: center;
            font-size: 1.6rem;
            margin-bottom: 20px;
            color: #0d47a1;
    }

    .form-container label{
            font-weight: bold;
            color: #354a5f;
    }

    .form-container input[type="text"], select {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
    }

    .form-container input {
        display: block;
        width: 100%;
        padding: 12px;
        margin: 10px 0;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-sizing: border-box;
    }

    .form-container input[type="submit"] {
        padding: 12px 25px;
            background-color: #4c8bf5;
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s;
            font-weight: bold;
            margin-top: 10px;
    }

    .form-container input[type="submit"]:hover {
        background-color: #3b6fbc;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(59, 111, 188, 0.3);
    }

    .table-container {
        width: 100%;
        max-width: 1000px;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        padding: 20px;
        margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
        }

        table th, table td {
            padding: 15px;
            text-align: center;
            font-size: 16px;
        }

        th {
            background-color: #0d47a1;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:hover {
            background-color: #f1f5f9;
        }

        .table-container h2 {
        text-align: center;
            font-size: 1.6rem;
            margin-bottom: 20px;
            color: #0d47a1;
    }


    .delete-btn,
    .edit-btn {
        padding: 10px 20px;
        margin-right: 10px;
        font-weight: bold;
        border-radius: 5px;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .delete-btn {
        background-color: #FF4C4C;
        color: white;
    }

    .delete-btn:hover {
        background-color: #e04b4b;
    }

    /* Responsive design */
    @media (max-width: 768px) {
        .header {
            flex-direction: column;
            text-align: center;
        }

        .header-nav {
            margin-top: 10px;
        }

        .table-container,
        .form-container {
            width: 100%;
        }
    }
    </style>
    <script>
        function confirmDelete(subjectCode) {
            if (confirm("Are you sure you want to delete this subject?")) {
                window.location.href = "delete_subject.php?subject_code=" + subjectCode;
            }
        }

        function openEditModal(subject) {
            document.getElementById('edit_subject_name').value = subject.subject_name;
            document.getElementById('edit_subject_code').value = subject.subject_code;
            document.getElementById('edit_credit_hours').value = subject.credit_hours;
            document.getElementById('edit_contact_hours').value = subject.contact_hours;
            document.getElementById('edit_subject_section').value = subject.subject_section;
            document.getElementById('editModal').style.display = 'flex';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
    </script>
</head>
<body>
    <div class="header">
        <h1>FCOM ADD DROP MANAGEMENT SYSTEM</h1>
        <div class="header-nav">
            <a href="bkrhome.php">Home</a>
            <a href="admin-logout.php">Logout</a>
        </div>
    </div>

    <main class="container">
        <div class="form-container">
        <h2>Add New Subject</h2>

        <?php if ($notification): ?>
            <div class="notification"><?php echo $notification; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <label for="subject_name">Subject Name:</label>
            <input type="text" name="subject_name" id="subject_name" required>

            <label for="subject_code">Subject Code:</label>
            <input type="text" name="subject_code" id="subject_code" required>

            <label for="credit_hours">Credit Hours:</label>
            <select name="credit_hours" id="credit_hours" required>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>

            <label for="contact_hours">Contact Hours:</label>
            <select name="contact_hours" id="contact_hours" required>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>

            <label for="subject_section">Subject Section:</label>
            <select name="subject_section" id="subject_section" required>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
            </select>

            <input type="submit" name="create_subject" value="Add">
        </form>
        </div>

        <div class="table-container">
        <h2>Subject List</h2>
            <?php if ($notification) { echo "<div class='notification'>$notification</div>"; } ?>
            <table>
                    <tr>
                        <th>Subject Name</th>
                        <th>Subject Code</th>
                        <th>Credit Hours</th>
                        <th>Contact Hours</th>
                        <th>Section</th>
                        <th>Actions</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?php echo $row['subject_name']; ?></td>
                            <td><?php echo $row['subject_code']; ?></td>
                            <td><?php echo $row['credit_hours']; ?></td>
                            <td><?php echo $row['contact_hours']; ?></td>
                            <td><?php echo $row['subject_section']; ?></td>
                            <td>
                                <button class="delete-btn" onclick="confirmDelete('<?php echo $row['subject_code']; ?>')">Delete</button>
                            </td>
                        </tr>
                    <?php } ?>
            </table>
        </div>
    </main>

</body>
</html>
